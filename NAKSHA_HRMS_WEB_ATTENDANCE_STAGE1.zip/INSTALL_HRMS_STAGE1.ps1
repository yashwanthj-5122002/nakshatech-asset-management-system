param([Parameter(Mandatory=$true)][string]$ProjectRoot)
$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath $ProjectRoot).Path
$patch = Join-Path $PSScriptRoot 'HRMS_STAGE1_INTEGRATION.patch'
if (!(Test-Path -LiteralPath $patch)) { throw 'HRMS patch file missing' }
if (!(Test-Path -LiteralPath (Join-Path $project 'frontend\src\App.tsx'))) { throw 'Wrong project root' }
Push-Location $project
try {
  git rev-parse --is-inside-work-tree | Out-Null
  git apply --check --whitespace=nowarn -- "$patch"
  if ($LASTEXITCODE -ne 0) { throw 'Patch does not fit your latest source. No files modified. Send git apply error to ChatGPT for a rebased patch.' }
  $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
  $backup = Join-Path $env:USERPROFILE "Downloads\NAKSHA_HRMS_Backup_$stamp"
  New-Item -ItemType Directory -Path $backup -Force | Out-Null
  $files = @('backend\app\main.py', 'frontend\src\App.tsx', 'frontend\src\components\Layout.tsx')
  foreach ($file in $files) {
    $src = Join-Path $project $file
    $out = Join-Path $backup $file
    New-Item -ItemType Directory -Path (Split-Path $out -Parent) -Force | Out-Null
    Copy-Item -LiteralPath $src -Destination $out -Force
  }
  git apply --whitespace=nowarn -- "$patch"
  if ($LASTEXITCODE -ne 0) { throw "Git apply failed. Original shared files are backed up at $backup" }
  Write-Host 'SUCCESS: HRMS Stage 1 code integrated.' -ForegroundColor Green
  Write-Host "Existing-file backup: $backup"
  Write-Host 'Next: docker compose up -d --build backend frontend'
  git status --short
} finally { Pop-Location }
