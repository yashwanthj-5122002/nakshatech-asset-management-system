NAKSHA TECH ERP - HRMS STAGE 1 WEB ATTENDANCE + LEAVE (LOCAL PATCH)
===============================================================
Source: user-uploaded nakshatech-asset-management-system(1).zip (2026-10-19).

Adds:
 - Leave Balance (provisional until HR configures policy)
 - Leave Application + pending cancellation
 - My Leave Calendar (application history)
 - Holiday Calendar with HR verified/unverified source references
 - ERP website Check-in / Check-out using server UTC and Asia/Kolkata work date
 - Attendance history and employee-supplied absence explanations
 - HR attendance dashboard and leave/absence approval
 - HR entitlement administration and holiday publication
 - Authenticated role guards; HR and Admin only can see/review staff records
 - Isolated new hrms_* database tables, created by existing startup create_all
 - No changes to Finance, production, GST, billing or other business rules.

Important limitations (before live use):
 - This is a scoped first integration; it is not a certified payroll/compliance HRMS.
 - Weekends/weekly offs and chargeable leave days need HR policies. Calendar-day
   balance shown is explicitly provisional. No payroll deductions occur.
 - Government holiday reference dates are NOT silently auto-published. HR must
   verify official holiday notices and applicable private-company policy.
 - Missing check-in does NOT prove an absence and is never assigned a fabricated
   reason. Employees explain missing time to HR.
 - Active ERP users appear in HR reporting. Employee Master records without linked
   activated ERP login cannot yet punch attendance.
 - No biometric/location tracking.
 - Existing ERP authentication/MFA restrictions are preserved.
 - No new REST changes to unrelated modules.

HOW TO INSTALL (Windows PowerShell, in VS Code)
1. Download NAKSHA_HRMS_WEB_ATTENDANCE_STAGE1.zip to Downloads.
2. Run:
   cd D:\shreeyansh\nakshatech-asset-management-system
   $zip = "$env:USERPROFILE\Downloads\NAKSHA_HRMS_WEB_ATTENDANCE_STAGE1.zip"
   $dest = "$env:TEMP\naksha_hrms_stage1"
   Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$dest\INSTALL_HRMS_STAGE1.ps1" -ProjectRoot (Get-Location).Path
3. Installer must report SUCCESS. If patch cannot apply, stop; do not force it.
4. Start:
   docker compose up -d --build backend frontend
   docker compose ps
   docker compose exec frontend npm run build
   Start-Process http://localhost:3100
5. Test endpoints and roles in browser:
   /hrms/attendance
   /hrms/leave/balance
   /hrms/leave/apply
   /hrms/leave/calendar
   /hrms/leave/holidays
   /hrms/hr  (HR / Admin only)

No git push, merge, database reset or deployment is performed by installer.
No .env or passwords included in ZIP.

KARNATAKA 2026 GOVERNMENT HOLIDAY REFERENCE
Official Government of Karnataka notice number DPAR 16 HHL 2025,
dated 17 November 2025. Public PDF copies:
https://cdn.vishwavani.news/media/documents/16_HHL_2025_%E0%B2%B8%E0%B2%B0%E0%B2%B5%E0%B2%A4%E0%B2%B0%E0%B2%95__%E0%B2%B0%E0%B2%9C..pdf
HR should validate the current notice and applicability to the company before
publishing; the app NEVER silently marks holidays as company-approved.

TEST RESULTS AT PACKAGE BUILD
- One targeted in-memory SQLite backend test PASSED (no PostgreSQL used).
- Python HRMS module compileall PASSED.
- New/modified frontend TSX syntax parse PASSED.
- Full TypeScript/Vite project build NOT run here: frontend node_modules absent.
- This is Stage 1, for local testing. No production/payroll guarantee.
