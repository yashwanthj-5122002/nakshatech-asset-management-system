param(
    [Parameter(Mandatory=$true)][string]$ProjectRoot
)
$ErrorActionPreference = 'Stop'
$patch = Join-Path $PSScriptRoot 'NAKSHA_HRMS_GREYTHR_UI_KARNATAKA_STAGE2.patch'
$required = @(
    'frontend/src/features/hrms/HRMSPages.tsx',
    'frontend/src/features/hrms/hrms.css'
)
if (!(Test-Path -LiteralPath $patch)) { throw 'Stage 2 Git patch missing from extracted ZIP.' }
if (!(Test-Path -LiteralPath $ProjectRoot -PathType Container)) { throw "Project folder not found: $ProjectRoot" }
Push-Location -LiteralPath $ProjectRoot
try {
    foreach ($file in $required) {
        if (!(Test-Path -LiteralPath $file)) {
            throw "STAGE 1 MISSING: $file was not found. Apply the Stage 1 HRMS patch first, then rerun Stage 2."
        }
    }
    & git rev-parse --show-toplevel | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'ProjectRoot must be a Git working tree.' }
    & git apply --check $patch
    if ($LASTEXITCODE -ne 0) {
        throw 'PATCH NOT COMPATIBLE: The HRMS source differs from the Stage 1 version. No files changed. Stop and request a merge tailored to your current branch.'
    }
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $backup = Join-Path $env:USERPROFILE "Downloads\NakshaHRMS_Stage2_Backup_$stamp"
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    foreach ($file in $required) {
        $out = Join-Path $backup $file
        New-Item -ItemType Directory -Path (Split-Path $out -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $file -Destination $out -Force
    }
    & git apply $patch
    if ($LASTEXITCODE -ne 0) { throw 'Git could not apply the patch; check Git output. Backup is preserved.' }
    & git diff --check -- frontend/src/features/hrms/HRMSPages.tsx frontend/src/features/hrms/hrms.css frontend/src/features/hrms/karnatakaGovernmentCalendar.ts
    if ($LASTEXITCODE -ne 0) { Write-Warning 'Whitespace warnings present; review before committing.' }
    Write-Host 'SUCCESS: Stage 2 HRMS interface installed. No unrelated files were modified.' -ForegroundColor Green
    Write-Host "Backup saved to: $backup" -ForegroundColor Cyan
    Write-Host 'Next: docker compose up -d frontend' -ForegroundColor Yellow
    Write-Host 'Then: docker compose exec frontend npm run build' -ForegroundColor Yellow
} finally {
    Pop-Location
}
