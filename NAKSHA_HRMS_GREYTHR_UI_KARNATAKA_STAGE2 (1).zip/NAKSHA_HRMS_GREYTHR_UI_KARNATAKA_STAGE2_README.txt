NAKSHA TECH ERP — HRMS STAGE 2 INTERFACE AND KARNATAKA GOVERNMENT REFERENCE
=========================================================================

REQUIRES: the earlier NAKSHA_HRMS_WEB_ATTENDANCE_STAGE1.zip patch already applied
          successfully. This Stage 2 patch is an ADD-ON, not a replacement.

Changed files (ONLY 3 frontend HRMS files):
  frontend/src/features/hrms/HRMSPages.tsx
  frontend/src/features/hrms/hrms.css
  frontend/src/features/hrms/karnatakaGovernmentCalendar.ts (new)

WHAT IS IMPLEMENTED
- greytHR-inspired visual layout, customized for Nakshatech rather than cloned.
- Swipe/scrollable leave balance cards and arrow controls.
- Leave Apply / Pending / History tabs, using existing HRMS endpoints.
- Month previous/next controls and swipe gesture for personal Leave Calendar.
- Side panel for month leave transactions.
- Karnataka Holiday Calendar: 12 monthly cards on desktop; swipeable month cards
  on touch/smaller screens; selectable month and monthly calendar grid.
- Government reference vs HR-published company holidays tabs.
- Government of Karnataka 2026 Notification-I and Restricted Holiday Annexure:
  20 general/reference dates + 21 restricted/reference dates, displayed without
  creating approved company holidays or changing the database.
- Official government site link: https://www.india.gov.in/calendar/karnataka
- HR holiday form defaults its source URL to the official government portal.
- Accessible month arrow controls, keyboard-accessible rail, reduced-motion CSS.
- No changes to authentication, Finance, GST, production, attendance backend,
  leave calculations, employee/HR role guards, or database schema.

SOURCE / IMPORTANT HOLIDAY POLICY
2026 holiday reference: Government of Karnataka DPAR 16 HHL 2025,
dated 17 November 2025, Notification-I and Restricted Holiday Annexure.
Reference portal: https://www.india.gov.in/calendar/karnataka
The portal renders month holidays dynamically; it is not documented as a stable
public API for server-side synchronization. The 2026 values are a read-only,
static reference transcribed from the government notification, NOT a live sync.
The government-office calendar does NOT automatically become the Nakshatech
paid-leave calendar. HR must approve/publish applicable holidays in the existing
HRMS Holiday Management form. Religious holiday dates can be officially amended.
For other years, use the source website until verified data is integrated.

INSTALL (Windows PowerShell in VS Code)
  cd D:\shreeyansh\nakshatech-asset-management-system
  $zip = "$env:USERPROFILE\Downloads\NAKSHA_HRMS_GREYTHR_UI_KARNATAKA_STAGE2.zip"
  $dest = "$env:TEMP\naksha_hrms_stage2"
  Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force
  powershell.exe -NoProfile -ExecutionPolicy Bypass `
      -File "$dest\INSTALL_NAKSHA_HRMS_STAGE2.ps1" `
      -ProjectRoot (Get-Location).Path

If the installer shows SUCCESS:
  docker compose up -d frontend
  docker compose exec frontend npm run build
  Start-Process "http://localhost:3100/hrms/leave/holidays"

If it stops because of a mismatch, DO NOT force it. Your local branch probably
has another version of the HRMS files. Supply its two existing files to make a
branch-specific merge patch. Preserve your Docker volumes and local Git edits.

VERIFY THESE ROUTES
  /hrms/leave/balance   - horizontal cards and arrow/swipe
  /hrms/leave/apply     - Apply/Pending/History tabs
  /hrms/leave/calendar  - prev/next month and leave transactions
  /hrms/leave/holidays  - government reference + HR company tabs, month cards
  /hrms/attendance     - existing check-in/out unchanged
  /hrms/hr             - existing HR-only dashboard unchanged

VALIDATION AT BUILD TIME
- 0 TSX/TS parse diagnostics for new/updated HRMS TS files.
- 41 calendar reference dates checked for valid ISO date notation.
- Stage 2 patch applies cleanly onto a clean Stage 1 HRMS baseline.
- Full frontend Vite/TypeScript project build MUST be run locally in Docker.
- No pushes/deployments performed.
