from __future__ import annotations

from collections import defaultdict
from datetime import date
from decimal import Decimal
import json
import logging

from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.core.config import settings
from app.core.departments import (
    DEFAULT_DEPARTMENT,
    SUPPORTED_DEPARTMENTS,
    department_for_pm_role,
    department_label,
    is_technical_pm_role,
    normalize_department_code,
    normalize_department_code_or_default,
    pm_role_for_department,
    user_department_matches,
)
from app.core.department_access import user_department_code
from app.models.entities import User, utc_now
from app.modules.employee_portal.service import send_email
from app.modules.finance.models import (
    ExpenseClaim,
    FinanceClient,
    FinanceProject,
    FinanceProjectAssignment,
    FinanceProjectMasterProfile,
)
from app.modules.finance.schemas import FinanceClientCreateRequest, FinanceClientProjectCreateRequest
from app.modules.finance.service import (
    approved_amount,
    claim_paid_amount,
    client_payload,
    create_client_project,
    create_finance_client,
    list_finance_clients,
    remaining_amount,
    set_project_status,
)
from app.modules.finance.visibility import exclude_hidden_projects, filter_visible_project_ids
from app.modules.management_projects.models import ManagementProjectLink
from app.modules.notifications.service import create_global_notification, resolve_recipient_users
from app.modules.operations.lifecycle_models import ProjectChangeRequest, ProjectFeedbackResponse, ProjectInvoice, ProjectReworkCycle
from app.modules.operations.lifecycle_schemas import InvoiceClose
from app.modules.operations.lifecycle_service import (
    CLOSED as LIFECYCLE_CLOSED,
    REWORK_OPEN,
    REWORK_PRODUCTION,
    REWORK_RESUBMITTED,
    _transition as lifecycle_transition,
    assert_finance_closable,
    close_invoice,
    enter_feedback_lifecycle,
    record_project_closed_timeline,
    sync_rework_cycle_with_packages,
)
from app.modules.operations.models import (
    OrthoDailyUpdate,
    OrthoProjectMember,
    OrthoProjectProfile,
    OrthoReview,
    OrthoWorkPackage,
    ProjectWorkflow,
    ProjectWorkflowEvent,
)
from app.modules.operations.schemas import (
    WorkflowDailyActivity,
    WorkflowDeliveryRequest,
    WorkflowFinanceClosure,
    WorkflowFinanceReview,
    WorkflowOperationalCompletion,
    WorkflowPMAssignment,
    WorkflowProjectCreate,
    WorkflowReviewRequest,
    WorkflowReworkAllocation,
    WorkflowReworkTeamConfirm,
    WorkflowTeamSetup,
    WorkflowWorkAllocation,
)
from app.modules.operations.production_stages import (
    STAGE_LABELS,
    STAGE_STATUSES,
    STAGE_STATUS_ATTR,
    STAGE_TIMESTAMP_ATTR,
    TRACKABLE_STAGES,
    aggregate_project_progress,
    package_production_progress,
    package_workflow_progress,
    stage_profile_for_department,
    stage_status,
)
from app.modules.operations.production_items import (
    delivery_readiness,
    item_dashboard_context,
    item_rows_for_viewer,
)

logger = logging.getLogger(__name__)

BD_ROLE = "bd"
FINANCE_ROLE = "finance"
ORTHO_ROLE = "ortho"
EMPLOYEE_ROLE = "employee"
ADMIN_ROLE = "admin"
MANAGEMENT_ROLE = "management"

WORKFLOW_DRAFT = "draft"
WORKFLOW_PENDING_FINANCE = "pending_finance_approval"
WORKFLOW_FINANCE_RETURNED = "finance_returned"
WORKFLOW_FINANCE_APPROVED = "finance_approved"
WORKFLOW_PM_ASSIGNED = "pm_assigned"
WORKFLOW_TEAM_ASSIGNED = "team_assigned"
WORKFLOW_IN_PROGRESS = "in_progress"
WORKFLOW_FINANCE_CLOSURE_PENDING = "finance_closure_pending"
WORKFLOW_CLOSED = "closed"


def normalized_workflow_status(status: str | None) -> str:
    """The one canonical form of ``ProjectWorkflow.status`` for dashboards, counts and UI decisions.

    The stored column holds two spellings of the same states: the legacy workflow writes lower-case
    (``finance_closure_pending``, ``closed``) while the V8.1 client-feedback/billing lifecycle writes
    upper-case (``FINANCE_CLOSURE_PENDING``, ``CLOSED``). Compare this value, never the raw column.
    """
    return (status or "").strip().lower()


# Statuses (normalized) in which the ORIGINAL team selection / work allocation may run. Both forms force the
# workflow status to team_assigned / in_progress, so they must never run against a lifecycle / rework state.
TEAM_SELECTION_STATUSES = {WORKFLOW_PM_ASSIGNED, WORKFLOW_TEAM_ASSIGNED, WORKFLOW_IN_PROGRESS}
WORK_ALLOCATION_STATUSES = {WORKFLOW_TEAM_ASSIGNED, WORKFLOW_IN_PROGRESS}
REWORK_STATUS_KEYS = {"rework_open", "rework_production", "rework_qc", "rework_qa", "rework_delivered", "rework_resubmitted"}


def _stage_unavailable_message(action: str, raw_status: str | None) -> str:
    status_key = normalized_workflow_status(raw_status)
    if status_key in REWORK_STATUS_KEYS:
        return (
            f"{action} is not repeated during a rework cycle. The assigned Project Manager confirms the rework team "
            "and the Team Lead allocates rework work from the Rework Cycle panel."
        )
    return f"{action} is not available while the project is {(raw_status or 'in this state').replace('_', ' ')}."


TEAM_ROLES = ("team_leader", "production", "qc", "qa")


def _event(
    db: Session,
    *,
    workflow: ProjectWorkflow,
    actor: User,
    event_type: str,
    to_status: str,
    comments: str | None = None,
) -> None:
    previous = workflow.status
    workflow.status = to_status
    workflow.updated_by_id = actor.id
    workflow.updated_at = utc_now()
    db.add(ProjectWorkflowEvent(
        project_id=workflow.project_id,
        event_type=event_type,
        from_status=previous,
        to_status=to_status,
        comments=(comments or "").strip() or None,
        actor_user_id=actor.id,
    ))


def _project_query():
    return (
        select(FinanceProject)
        .options(
            selectinload(FinanceProject.client),
            selectinload(FinanceProject.master_profile).selectinload(FinanceProjectMasterProfile.project_manager),
            selectinload(FinanceProject.assignments).selectinload(FinanceProjectAssignment.user),
        )
    )


def _project(db: Session, project_id: int) -> FinanceProject:
    row = db.scalar(_project_query().where(FinanceProject.id == project_id))
    if row is None:
        raise ValueError("Project not found")
    return row


def _workflow(db: Session, project_id: int) -> ProjectWorkflow:
    row = db.get(ProjectWorkflow, project_id)
    if row is None:
        raise ValueError("Project workflow not found")
    return row


def _client_code(project: FinanceProject) -> str | None:
    return project.client.client_code if project.client else None


def _client_name(project: FinanceProject) -> str | None:
    return project.client.client_name if project.client else project.client_name


def _pm(project: FinanceProject) -> User | None:
    return project.master_profile.project_manager if project.master_profile else None


def _events(db: Session, project_id: int) -> list[dict]:
    rows = db.scalars(
        select(ProjectWorkflowEvent)
        .where(ProjectWorkflowEvent.project_id == project_id)
        .order_by(ProjectWorkflowEvent.created_at.asc(), ProjectWorkflowEvent.id.asc())
    ).all()
    users = {
        user.id: user
        for user in db.scalars(select(User).where(User.id.in_({row.actor_user_id for row in rows}))).all()
    } if rows else {}
    return [
        {
            "id": row.id,
            "event_type": row.event_type,
            "from_status": row.from_status,
            "to_status": row.to_status,
            "comments": row.comments,
            "actor_user_id": row.actor_user_id,
            "actor_name": users[row.actor_user_id].full_name if row.actor_user_id in users else None,
            "actor_role": users[row.actor_user_id].role if row.actor_user_id in users else None,
            "created_at": row.created_at.isoformat(),
        }
        for row in rows
    ]


def _attachment_references(workflow: ProjectWorkflow) -> list[str]:
    if not workflow.attachment_references:
        return []
    try:
        value = json.loads(workflow.attachment_references)
    except (TypeError, ValueError):
        return [item.strip() for item in workflow.attachment_references.splitlines() if item.strip()]
    return [str(item).strip() for item in value if str(item).strip()] if isinstance(value, list) else []


def _full_project_payload(db: Session, project: FinanceProject, workflow: ProjectWorkflow) -> dict:
    pm = _pm(project)
    client = project.client
    client_profile = client.master_profile if client else None
    owner = db.get(User, workflow.bd_owner_user_id)
    reviewer = db.get(User, workflow.finance_reviewer_id) if workflow.finance_reviewer_id else None
    creator = db.get(User, project.created_by_id) if project.created_by_id else None
    events = _events(db, project.id)
    return {
        "id": project.id,
        "project_code": project.project_code,
        "project_name": project.project_name,
        "client_id": project.client_id,
        "client_code": _client_code(project),
        "client_name": _client_name(project),
        "start_date": project.start_date.isoformat() if project.start_date else None,
        "end_date": project.end_date.isoformat() if project.end_date else None,
        "description": project.description,
        "scope_text": workflow.scope_text,
        "quantity": float(workflow.quantity) if workflow.quantity is not None else None,
        "quantity_unit": workflow.quantity_unit,
        "priority": workflow.priority,
        "performing_department_code": workflow.performing_department_code,
        "performing_department_label": department_label(workflow.performing_department_code),
        "commercial_value": float(workflow.commercial_value) if workflow.commercial_value is not None else None,
        "currency": workflow.currency,
        "po_wo_number": workflow.po_wo_number,
        "attachment_references": _attachment_references(workflow),
        "workflow_status": workflow.status,
        "normalized_status": normalized_workflow_status(workflow.status),
        "finance_feedback": workflow.finance_feedback,
        "submission_count": workflow.submission_count or sum(1 for event in events if event["event_type"] == "submitted_to_finance"),
        "finance_reviewer_id": workflow.finance_reviewer_id,
        "finance_reviewer_name": reviewer.full_name if reviewer else None,
        "finance_reviewed_at": workflow.finance_reviewed_at.isoformat() if workflow.finance_reviewed_at else None,
        "project_manager_id": pm.id if pm else None,
        "project_manager_name": pm.full_name if pm else None,
        "project_manager_email": pm.email if pm else None,
        "submitted_at": workflow.submitted_at.isoformat() if workflow.submitted_at else None,
        "approved_at": workflow.approved_at.isoformat() if workflow.approved_at else None,
        "operational_completed_at": workflow.operational_completed_at.isoformat() if workflow.operational_completed_at else None,
        "completion_date": workflow.completion_date.isoformat() if workflow.completion_date else None,
        "final_delivery_reference": workflow.final_delivery_reference,
        "completion_remarks": workflow.completion_remarks,
        "finance_closed_at": workflow.finance_closed_at.isoformat() if workflow.finance_closed_at else None,
        "finance_closure_remarks": workflow.finance_closure_remarks,
        "created_at": project.created_at.isoformat(),
        "updated_at": project.updated_at.isoformat(),
        "created_by_name": creator.full_name if creator else None,
        "submitted_by_name": owner.full_name if owner else None,
        "submitted_by_email": owner.email if owner else None,
        "client": {
            "organization_name": client.client_name if client else project.client_name,
            "client_code": client.client_code if client else None,
            "client_email": client.client_email if client else None,
            "organization_email": client_profile.organization_email if client_profile else None,
            "location": (client.address or client.country) if client else None,
            "gst_number": client.gst_number if client else None,
            "contact_person_name": client.contact_person_name if client else None,
            "contact_person_email": client_profile.contact_person_email if client_profile else None,
            "contact_person_phone": client.contact_person_phone if client and client.contact_person_phone != "Not provided" else None,
            "bd_person": client_profile.bd_name if client_profile and client_profile.bd_name else (client.source_person_name if client else None),
        },
        "events": events,
        # BD / Finance / Management payload only (the Ortho PM dashboard builds its own restricted payload).
        "commercial_summary": _commercial_summary(db, project.id),
    }


def _commercial_summary(db: Session, project_id: int) -> dict:
    from app.modules.commercial.service import commercial_summary

    return commercial_summary(db, project_id=project_id)


def project_manager_options(db: Session, *, department_code: str | None = None) -> list[dict]:
    """Active technical Project Manager accounts.

    ``department_code`` restricts the list to the one technical PM role that performs that
    department (e.g. LiDAR projects only ever show LiDAR PMs). Omitted, every supported
    department's PM role is returned (a cross-department directory view).
    """
    roles = [pm_role_for_department(department_code)] if department_code else [pm_role_for_department(code) for code in SUPPORTED_DEPARTMENTS]
    users = db.scalars(
        select(User).where(
            User.role.in_(roles),
            User.is_active.is_(True),
            User.account_status.in_(["active", "pending_mfa"]),
        ).order_by(User.full_name.asc(), User.email.asc())
    ).all()
    return [
        {
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "employee_id": user.employee_id,
            "department": user.department,
            "designation": user.designation,
            "performing_department_code": department_for_pm_role(user.role),
        }
        for user in users
    ]


def employee_options(db: Session, *, department_code: str | None = None) -> list[dict]:
    """Active Employee accounts, optionally restricted to the given performing department.

    Employee.role is always the generic ``employee`` role; only ``User.department`` (free
    text set at seeding/HR time) distinguishes which department an employee belongs to, so a
    Team Lead can never allocate work to, and a PM can never add, an employee from another
    department even through a direct API call.
    """
    users = db.scalars(
        select(User).where(
            User.role == EMPLOYEE_ROLE,
            User.is_active.is_(True),
            User.account_status.in_(["active", "pending_mfa"]),
        ).order_by(User.full_name.asc(), User.email.asc())
    ).all()
    if department_code:
        users = [user for user in users if user_department_matches(user.department, department_code)]
    return [
        {
            "id": user.id,
            "full_name": user.full_name,
            "email": user.email,
            "employee_id": user.employee_id,
            "department": user.department,
            "designation": user.designation,
        }
        for user in users
    ]


def bd_dashboard(db: Session, *, actor: User, role: str) -> dict:
    query = _project_query().join(ProjectWorkflow, ProjectWorkflow.project_id == FinanceProject.id)
    query = exclude_hidden_projects(db, query)
    if role == BD_ROLE:
        query = query.where(
            ProjectWorkflow.bd_owner_user_id == actor.id,
            FinanceProject.project_source_team != "management",
        )
    projects = list(db.scalars(query.order_by(FinanceProject.updated_at.desc(), FinanceProject.id.desc())).unique().all())
    workflows = {row.project_id: row for row in db.scalars(select(ProjectWorkflow).where(ProjectWorkflow.project_id.in_([p.id for p in projects]))).all()} if projects else {}
    payloads = [_full_project_payload(db, project, workflows[project.id]) for project in projects]
    return {
        "summary": {
            "total": len(payloads),
            "draft": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_DRAFT),
            "pending_finance": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_PENDING_FINANCE),
            "returned": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_FINANCE_RETURNED),
            "approved": sum(1 for p in payloads if p["normalized_status"] in {WORKFLOW_FINANCE_APPROVED, WORKFLOW_PM_ASSIGNED, WORKFLOW_TEAM_ASSIGNED, WORKFLOW_IN_PROGRESS}),
            "completion_pending": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_FINANCE_CLOSURE_PENDING),
            "closed": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_CLOSED),
        },
        "clients": [client_payload(client) for client in list_finance_clients(db)
                    if role != BD_ROLE or client.source_team != "management"],
        "project_managers": project_manager_options(db),
        "project_managers_by_department": {code: project_manager_options(db, department_code=code) for code in SUPPORTED_DEPARTMENTS},
        "departments": [{"code": code, "label": department_label(code)} for code in SUPPORTED_DEPARTMENTS],
        "projects": payloads,
    }


def create_bd_client(db: Session, *, actor: User, payload: FinanceClientCreateRequest) -> FinanceClient:
    # BD is the authoritative creator. Force the source metadata to BD while keeping
    # all other Client Master validation and duplicate checks unchanged.
    data = payload.model_copy(update={
        "source_team": "bd_team",
        "source_person_name": payload.source_person_name or actor.full_name,
        "bd_name": payload.bd_name or actor.full_name,
    })
    return create_finance_client(db, actor=actor, payload=data)


def create_bd_project(db: Session, *, actor: User, payload: WorkflowProjectCreate) -> tuple[FinanceProject, ProjectWorkflow]:
    client = db.get(FinanceClient, payload.client_id)
    if client is None or not client.is_active or client.source_team == "management":
        raise ValueError("Select an active BD client ID before creating the project")
    finance_payload = FinanceClientProjectCreateRequest(
        project_code=payload.project_code,
        project_name=payload.project_name,
        task=payload.scope_text,
        project_status="inactive",
        project_manager_id=None,
        reporting_manager_id=None,
        assigned_employee_ids=[],
        project_source_team="bd_team",
        project_source_person_name=actor.full_name,
        client_awarded_by_name=None,
        project_award_date=None,
        description=payload.description,
        start_date=payload.start_date,
        end_date=payload.end_date,
        is_active=False,
    )
    project = create_client_project(db, client=client, actor=actor, payload=finance_payload)
    workflow = ProjectWorkflow(
        project_id=project.id,
        bd_owner_user_id=actor.id,
        status=WORKFLOW_DRAFT,
        performing_department_code=normalize_department_code_or_default(payload.performing_department_code),
        scope_text=payload.scope_text,
        quantity=payload.quantity,
        quantity_unit=payload.quantity_unit,
        priority=payload.priority,
        commercial_value=payload.commercial_value,
        currency=payload.currency.upper(),
        po_wo_number=payload.po_wo_number,
        attachment_references=json.dumps(payload.attachment_references),
        created_by_id=actor.id,
        updated_by_id=actor.id,
    )
    db.add(workflow)
    db.flush()
    db.add(ProjectWorkflowEvent(
        project_id=project.id,
        event_type="bd_project_created",
        from_status=None,
        to_status=WORKFLOW_DRAFT,
        comments="Project created by Business Development",
        actor_user_id=actor.id,
    ))
    db.flush()
    if payload.commercial is not None:
        # Same session/transaction as the project: any commercial failure (validation, FX unavailable) aborts the
        # whole create, so a project is never left behind without the Revision 1 BD entered.
        from app.modules.commercial.service import upsert_baseline_estimate

        upsert_baseline_estimate(db, actor=actor, project_id=project.id, payload=payload.commercial)
    return project, workflow


def update_bd_project(
    db: Session, *, actor: User, project_id: int, payload: WorkflowProjectCreate
) -> tuple[FinanceProject, ProjectWorkflow]:
    """Allow the BD owner to correct a Draft/Finance Returned project before resubmission.

    The manually entered Project ID remains authoritative. Changes are audited through
    the workflow event stream; Finance-approved/operational records are intentionally
    immutable through this endpoint.
    """
    workflow = _workflow(db, project_id)
    if workflow.bd_owner_user_id != actor.id:
        raise PermissionError("Only the BD owner can correct this project")
    if workflow.status not in {WORKFLOW_DRAFT, WORKFLOW_FINANCE_RETURNED}:
        raise ValueError("Only Draft or Finance Returned projects can be edited by BD")

    project = _project(db, project_id)
    client = db.get(FinanceClient, payload.client_id)
    if client is None or not client.is_active:
        raise ValueError("Select an active existing Client ID")

    duplicate = db.scalar(
        select(FinanceProject.id).where(
            func.lower(FinanceProject.project_code) == payload.project_code.lower(),
            FinanceProject.id != project.id,
        ).limit(1)
    )
    if duplicate is not None:
        raise ValueError(f"Project ID {payload.project_code} is already in use")

    project.project_code = payload.project_code
    project.project_name = payload.project_name
    project.client_id = client.id
    project.client_name = client.client_name
    project.project_source_team = "bd_team"
    project.project_source_person_name = actor.full_name
    project.description = payload.description
    project.start_date = payload.start_date
    project.end_date = payload.end_date
    project.updated_at = utc_now()
    if project.master_profile is not None:
        project.master_profile.task = payload.scope_text
        project.master_profile.updated_by_id = actor.id
        project.master_profile.updated_at = utc_now()

    workflow.scope_text = payload.scope_text
    workflow.quantity = payload.quantity
    workflow.quantity_unit = payload.quantity_unit
    workflow.priority = payload.priority
    workflow.performing_department_code = normalize_department_code_or_default(payload.performing_department_code)
    workflow.commercial_value = payload.commercial_value
    workflow.currency = payload.currency.upper()
    workflow.po_wo_number = payload.po_wo_number
    workflow.attachment_references = json.dumps(payload.attachment_references)
    workflow.updated_by_id = actor.id
    workflow.updated_at = utc_now()
    # Keep Finance feedback visible until BD resubmits so the correction reason is not lost.
    db.add(ProjectWorkflowEvent(
        project_id=project.id,
        event_type="bd_project_corrected",
        from_status=workflow.status,
        to_status=workflow.status,
        comments="BD updated project details before Finance resubmission",
        actor_user_id=actor.id,
    ))
    db.flush()
    if payload.commercial is not None:
        # Corrects the SAME Revision 1 row (identity and history preserved); locked baselines are refused.
        from app.modules.commercial.service import upsert_baseline_estimate

        upsert_baseline_estimate(db, actor=actor, project_id=project_id, payload=payload.commercial)
    return project, workflow


def submit_project_to_finance(db: Session, *, actor: User, project_id: int) -> ProjectWorkflow:
    workflow = _workflow(db, project_id)
    if workflow.bd_owner_user_id != actor.id:
        raise PermissionError("Only the BD owner can submit this project to Finance")
    if workflow.status not in {WORKFLOW_DRAFT, WORKFLOW_FINANCE_RETURNED}:
        raise ValueError("Only Draft or Finance Returned projects can be submitted to Finance")
    # Commercial Revision 1 is submitted together with the project (and is required for a never-submitted project).
    from app.modules.commercial.service import prepare_revision1_for_finance_submission

    prepare_revision1_for_finance_submission(db, actor=actor, project_id=project_id)
    workflow.finance_feedback = None
    workflow.submitted_at = utc_now()
    workflow.submission_count = int(workflow.submission_count or 0) + 1
    _event(db, workflow=workflow, actor=actor, event_type="submitted_to_finance", to_status=WORKFLOW_PENDING_FINANCE)
    project = _project(db, project_id)
    create_global_notification(
        db,
        event_type="workflow.project.submitted_finance",
        title=f"Finance review required: {project.project_code}",
        message=f"BD submitted Project ID {project.project_code} for Finance approval. Client ID: {_client_code(project) or 'Not recorded'}.",
        category="approval",
        target_url=f"/finance?project={project.id}",
        recipient_roles=[FINANCE_ROLE],
        # Popup experience (additive): Finance must act, so the center popup offers
        # Approve / Return. Closing the popup never resolves this - only the real
        # finance_review_project action does.
        severity="info",
        requires_action=True,
        metadata={
            "project_id": project.id,
            "project_name": project.project_code,
            "client_name": _client_code(project) or None,
            "submitted_by": actor.full_name or actor.email,
            "submitted_at": workflow.submitted_at.isoformat() if workflow.submitted_at else None,
            "current_stage": "Finance Approval",
            "amount": workflow.commercial_value,
            "currency": workflow.currency,
        },
    )
    db.flush()
    return workflow


def _safe_send_email(*, recipient: str, subject: str, body: str, from_name: str) -> None:
    try:
        send_email(recipient=recipient, subject=subject, body=body, from_name=from_name)
    except Exception:
        logger.exception("Workflow email delivery failed to %s", recipient)


def email_finance_submission(db: Session, *, project_id: int) -> None:
    project = _project(db, project_id)
    workflow = _workflow(db, project_id)
    for user in resolve_recipient_users(db, recipient_roles=[FINANCE_ROLE]):
        _safe_send_email(
            recipient=user.email,
            subject=f"[{project.project_code}] Project approval required",
            body=(
                f"Hello {user.full_name},\n\n"
                f"Business Development submitted a project for Finance approval.\n\n"
                f"Project ID: {project.project_code}\n"
                f"Client ID: {_client_code(project) or 'Not recorded'}\n"
                f"Project Name: {project.project_name}\n"
                f"Start Date: {project.start_date.isoformat() if project.start_date else 'Not recorded'}\n"
                f"End Date: {project.end_date.isoformat() if project.end_date else 'Not recorded'}\n"
                f"Commercial Value: {workflow.currency} {workflow.commercial_value if workflow.commercial_value is not None else 'Not recorded'}\n"
                f"PO / WO: {workflow.po_wo_number or 'Not recorded'}\n\n"
                f"Review in ERP: {settings.app_public_url.rstrip('/')}/finance\n\n"
                "Nakshatech ERP"
            ),
            from_name="Nakshatech BD -> Finance",
        )


def _project_expense_summary(db: Session, project_id: int) -> dict:
    claims = list(db.scalars(
        select(ExpenseClaim)
        .options(selectinload(ExpenseClaim.payments))
        .where(ExpenseClaim.project_id == project_id)
    ).unique().all())
    requested = sum((claim.total_amount or Decimal("0")) for claim in claims)
    approved = sum((approved_amount(claim) for claim in claims), Decimal("0"))
    paid = sum((claim_paid_amount(claim) for claim in claims), Decimal("0"))
    outstanding = sum((remaining_amount(claim) for claim in claims), Decimal("0"))
    unresolved_statuses = {
        "submitted", "admin_approved", "finance_approved", "partially_paid", "sent_back",
    }
    return {
        "claim_count": len(claims),
        "requested_amount": float(requested),
        "approved_amount": float(approved),
        "paid_amount": float(paid),
        "outstanding_amount": float(outstanding),
        "unresolved_claim_count": sum(1 for claim in claims if claim.status in unresolved_statuses),
    }


def _finance_closure_readiness(db: Session, workflow: ProjectWorkflow, normalized_status: str) -> tuple[bool, str | None]:
    """Ask the authoritative closure guard whether Finance Closure would be accepted right now.

    This only *reads* through ``assert_finance_closable`` (the same guard ``finance_close_project``
    enforces on submit); it never reimplements or bypasses it.
    """
    if normalized_status != WORKFLOW_FINANCE_CLOSURE_PENDING:
        return False, None
    try:
        assert_finance_closable(db, workflow=workflow)
    except ValueError as exc:
        return False, str(exc)
    return True, None


def finance_dashboard(db: Session) -> dict:
    query = exclude_hidden_projects(
        db,
        _project_query().join(ProjectWorkflow, ProjectWorkflow.project_id == FinanceProject.id),
    )
    projects = list(db.scalars(
        query.order_by(FinanceProject.updated_at.desc(), FinanceProject.id.desc())
    ).unique().all())
    workflows = {row.project_id: row for row in db.scalars(select(ProjectWorkflow)).all()}
    payloads = []
    for project in projects:
        if project.id not in workflows:
            continue
        payload = _full_project_payload(db, project, workflows[project.id])
        payload["expense_summary"] = _project_expense_summary(db, project.id)
        payload["finance_closable"], payload["finance_closure_blocker"] = _finance_closure_readiness(
            db, workflows[project.id], payload["normalized_status"]
        )
        payloads.append(payload)
    return {
        "summary": {
            "pending_approval": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_PENDING_FINANCE),
            "returned": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_FINANCE_RETURNED),
            "approved": sum(1 for p in payloads if p["normalized_status"] in {WORKFLOW_FINANCE_APPROVED, WORKFLOW_PM_ASSIGNED, WORKFLOW_TEAM_ASSIGNED, WORKFLOW_IN_PROGRESS}),
            "closure_pending": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_FINANCE_CLOSURE_PENDING),
            "closed": sum(1 for p in payloads if p["normalized_status"] == WORKFLOW_CLOSED),
        },
        "projects": payloads,
    }


def finance_review_project(db: Session, *, actor: User, project_id: int, payload: WorkflowFinanceReview) -> ProjectWorkflow:
    workflow = _workflow(db, project_id)
    if workflow.status != WORKFLOW_PENDING_FINANCE:
        raise ValueError("This project is not waiting for Finance approval")
    project = _project(db, project_id)
    workflow.finance_reviewer_id = actor.id
    workflow.finance_reviewed_at = utc_now()
    if payload.decision == "return":
        feedback = (payload.feedback or "").strip()
        if not feedback:
            raise ValueError("Finance feedback is mandatory when returning a project")
        workflow.finance_feedback = feedback
        workflow.returned_at = utc_now()
        from app.modules.commercial.service import mark_revision1_returned

        mark_revision1_returned(db, actor=actor, project_id=project_id, feedback=feedback)
        _event(db, workflow=workflow, actor=actor, event_type="finance_returned", to_status=WORKFLOW_FINANCE_RETURNED, comments=feedback)
        title = f"Finance returned {project.project_code}"
        message = f"Finance returned Project ID {project.project_code}. Feedback: {feedback}"
    else:
        # Freeze the additive Commercial baseline in the same transaction as the
        # authoritative Finance project approval. Legacy projects without a detailed
        # estimate remain valid unless the feature flag explicitly requires one.
        from app.modules.commercial.service import freeze_baseline_on_finance_approval

        freeze_baseline_on_finance_approval(db, actor=actor, project_id=project_id)
        workflow.finance_feedback = None
        workflow.approved_at = utc_now()
        set_project_status(db, project=project, actor=actor, project_status="active")
        _event(db, workflow=workflow, actor=actor, event_type="finance_approved", to_status=WORKFLOW_FINANCE_APPROVED, comments=payload.feedback)
        title = f"Finance approved {project.project_code}"
        message = f"Finance approved Project ID {project.project_code}. You can now assign the Ortho Project Manager."
    create_global_notification(
        db,
        event_type=f"workflow.project.finance_{payload.decision}",
        title=title,
        message=message,
        category="approval",
        target_url=f"/bd/projects?project={project.id}",
        recipient_user_ids=[workflow.bd_owner_user_id],
        severity="danger" if payload.decision == "return" else "success",
        requires_action=payload.decision == "return",
        metadata={
            "project_id": project.id,
            "project_name": project.project_code,
            "client_name": _client_code(project) or None,
            "returned_by": "Finance" if payload.decision == "return" else None,
            "status": "Correction Required" if payload.decision == "return" else "Approved",
            "reason": (payload.feedback or None) if payload.decision == "return" else None,
            "required_action": (
                "Upload the missing Work Order and resubmit."
                if payload.decision == "return"
                else None
            ),
            "decided_by": actor.full_name or actor.email,
        },
    )
    # The Finance approval/return action really completed, so the Finance pending
    # notification is now resolved. This runs inside the same transaction as the
    # workflow transition - the popup itself never performs this.
    from app.modules.notifications.service import resolve_notifications

    resolve_notifications(
        db,
        recipient_user_ids=[user.id for user in resolve_recipient_users(db, recipient_roles=[FINANCE_ROLE])],
        event_type="workflow.project.submitted_finance",
        resolved_by_id=actor.id,
        resolution_note=f"Finance {payload.decision}",
    )
    db.flush()
    return workflow


def email_bd_finance_review(db: Session, *, project_id: int, decision: str) -> None:
    project = _project(db, project_id)
    workflow = _workflow(db, project_id)
    owner = db.get(User, workflow.bd_owner_user_id)
    if owner is None:
        return
    status_text = "approved" if decision == "approve" else "returned for correction"
    feedback_line = f"\nFinance Feedback: {workflow.finance_feedback}" if workflow.finance_feedback else ""
    _safe_send_email(
        recipient=owner.email,
        subject=f"[{project.project_code}] Finance {status_text}",
        body=(
            f"Hello {owner.full_name},\n\n"
            f"Finance has {status_text} Project ID {project.project_code}.\n"
            f"Client ID: {_client_code(project) or 'Not recorded'}"
            f"{feedback_line}\n\n"
            f"ERP BD Dashboard: {settings.app_public_url.rstrip('/')}/bd\n\n"
            "Nakshatech ERP"
        ),
        from_name="Nakshatech Finance -> BD",
    )


def _ensure_profile_and_pm_member(db: Session, *, project: FinanceProject, workflow: ProjectWorkflow, actor: User, pm: User) -> OrthoProjectProfile:
    profile = db.get(OrthoProjectProfile, project.id)
    if profile is None:
        profile = OrthoProjectProfile(
            project_id=project.id,
            opportunity_id=None,
            total_area=workflow.quantity,
            area_unit=workflow.quantity_unit,
            scope_text=workflow.scope_text,
            planned_hours=None,
            target_value=None,
            project_manager_user_id=pm.id,
            status="active",
            created_by_id=actor.id,
        )
        db.add(profile)
        db.flush()
    else:
        profile.total_area = workflow.quantity
        profile.area_unit = workflow.quantity_unit
        profile.scope_text = workflow.scope_text
        profile.project_manager_user_id = pm.id
        if profile.status in {"closed", "delivered"}:
            raise ValueError("Project Manager cannot be changed after operational completion")

    rows = list(db.scalars(select(OrthoProjectMember).where(
        OrthoProjectMember.project_id == project.id,
        OrthoProjectMember.member_role == "project_manager",
    )).all())
    selected = None
    for row in rows:
        row.is_active = row.user_id == pm.id
        row.assigned_by_id = actor.id
        if row.user_id == pm.id:
            selected = row
    if selected is None:
        db.add(OrthoProjectMember(
            project_id=project.id,
            user_id=pm.id,
            member_role="project_manager",
            is_active=True,
            assigned_by_id=actor.id,
        ))
    db.flush()
    return profile


def assign_project_manager(
    db: Session, *, actor: User, project_id: int, payload: WorkflowPMAssignment,
    allow_management_finance: bool = False,
) -> tuple[ProjectWorkflow, User]:
    workflow = _workflow(db, project_id)
    project = _project(db, project_id)
    finance_management = allow_management_finance and (actor.role or "").lower() == "finance" and project.project_source_team == "management"
    if not finance_management and workflow.bd_owner_user_id != actor.id:
        raise PermissionError("Only the BD owner can assign the Project Manager")
    if allow_management_finance and not finance_management:
        raise PermissionError("Only Finance can assign a Management Project Manager")
    if workflow.status not in {WORKFLOW_FINANCE_APPROVED, WORKFLOW_PM_ASSIGNED}:
        raise ValueError("Project Manager can be assigned only after Finance approval and before the project team starts work")
    expected_role = pm_role_for_department(workflow.performing_department_code)
    pm = db.get(User, payload.project_manager_id)
    if pm is None or not pm.is_active or pm.role != expected_role:
        raise ValueError(f"Select an active {department_label(workflow.performing_department_code)} Project Manager account")
    if project.master_profile is None:
        project.master_profile = FinanceProjectMasterProfile(
            project_id=project.id,
            project_status="active",
            project_manager_id=pm.id,
            created_by_id=actor.id,
            updated_by_id=actor.id,
        )
        db.add(project.master_profile)
    else:
        project.master_profile.project_manager_id = pm.id
        project.master_profile.updated_by_id = actor.id
        project.master_profile.updated_at = utc_now()
    _ensure_profile_and_pm_member(db, project=project, workflow=workflow, actor=actor, pm=pm)
    workflow.pm_assigned_at = utc_now()
    _event(db, workflow=workflow, actor=actor, event_type="finance_management_assigned_pm" if finance_management else "bd_assigned_pm", to_status=WORKFLOW_PM_ASSIGNED, comments=f"PM user {pm.id}")
    create_global_notification(
        db,
        event_type="workflow.project.pm_assigned",
        title=f"New project assigned: {project.project_code}",
        message=f"You are the {department_label(workflow.performing_department_code)} Project Manager for Project ID {project.project_code}. Client ID: {_client_code(project) or 'Not recorded'}.",
        category="system",
        target_url=f"/ortho/project-360/{project.id}",
        recipient_user_ids=[pm.id],
        # Actionable and ASSIGNMENT-scoped: only the assigned PM is a recipient.
        # A different PM must never receive this.
        severity="warning",
        requires_action=True,
        metadata={
            "project_name": project.project_code,
            "client_name": _client_code(project) or None,
            "assigned_role": department_label(workflow.performing_department_code),
            "amount": workflow.commercial_value,
            "currency": workflow.currency,
        },
    )
    db.flush()
    return workflow, pm


def email_project_manager_assignment(db: Session, *, project_id: int, pm_id: int) -> None:
    project = _project(db, project_id)
    workflow = _workflow(db, project_id)
    pm = db.get(User, pm_id)
    if pm is None:
        return
    assigning_team = "Finance" if project.project_source_team == "management" else "Business Development"
    _safe_send_email(
        recipient=pm.email,
        subject=f"[{project.project_code}] {department_label(workflow.performing_department_code)} Project Manager assignment",
        body=(
            f"Hello {pm.full_name},\n\n"
            f"{assigning_team} assigned you as the {department_label(workflow.performing_department_code)} Project Manager.\n\n"
            f"Project ID: {project.project_code}\n"
            f"Client ID: {_client_code(project) or 'Not recorded'}\n"
            f"Start Date: {project.start_date.isoformat() if project.start_date else 'Not recorded'}\n"
            f"End Date: {project.end_date.isoformat() if project.end_date else 'Not recorded'}\n"
            f"Scope: {workflow.scope_text or 'Not recorded'}\n"
            f"Quantity: {workflow.quantity if workflow.quantity is not None else 'Not recorded'} {workflow.quantity_unit}\n\n"
            f"ERP Ortho Dashboard: {settings.app_public_url.rstrip('/')}/ortho\n\n"
            "Nakshatech ERP"
        ),
        from_name="Nakshatech Finance -> Project Manager" if project.project_source_team == "management" else "Nakshatech BD -> Ortho",
    )


def _is_pm(project: FinanceProject, user_id: int) -> bool:
    return bool(project.master_profile and project.master_profile.project_manager_id == user_id)


def _active_member_ids(db: Session, *, project_id: int, role: str) -> set[int]:
    return {int(value) for value in db.scalars(select(OrthoProjectMember.user_id).where(
        OrthoProjectMember.project_id == project_id,
        OrthoProjectMember.member_role == role,
        OrthoProjectMember.is_active.is_(True),
    )).all()}


def _validate_employee(db: Session, user_id: int, label: str, *, department_code: str | None = None) -> User:
    user = db.get(User, user_id)
    if user is None or not user.is_active or user.role != EMPLOYEE_ROLE:
        raise ValueError(f"Selected {label} must be an active Employee account")
    if department_code and not user_department_matches(user.department, department_code):
        raise ValueError(f"Selected {label} must belong to the {department_label(department_code)} department")
    return user


def _assert_removable_members_not_assigned(db: Session, *, project_id: int, role: str, removed_ids: set[int]) -> None:
    if not removed_ids:
        return
    field = {
        "team_leader": OrthoWorkPackage.team_leader_user_id,
        "production": OrthoWorkPackage.production_user_id,
        "qc": OrthoWorkPackage.qc_user_id,
        "qa": OrthoWorkPackage.qa_user_id,
    }[role]
    referenced = set(db.scalars(select(field).where(
        OrthoWorkPackage.project_id == project_id,
        field.in_(removed_ids),
        OrthoWorkPackage.current_stage != "delivered",
    )).all())
    if referenced:
        raise ValueError(f"Reassign active work packages before removing {role.replace('_', ' ')} employee(s): {sorted(referenced)}")


def _set_role_members(db: Session, *, project_id: int, actor: User, role: str, selected_ids: set[int]) -> None:
    current = _active_member_ids(db, project_id=project_id, role=role)
    _assert_removable_members_not_assigned(db, project_id=project_id, role=role, removed_ids=current - selected_ids)
    rows = list(db.scalars(select(OrthoProjectMember).where(
        OrthoProjectMember.project_id == project_id,
        OrthoProjectMember.member_role == role,
    )).all())
    existing = {(row.user_id, row.member_role): row for row in rows}
    for row in rows:
        row.is_active = row.user_id in selected_ids
        row.assigned_by_id = actor.id
    for user_id in selected_ids:
        if (user_id, role) not in existing:
            db.add(OrthoProjectMember(
                project_id=project_id,
                user_id=user_id,
                member_role=role,
                is_active=True,
                assigned_by_id=actor.id,
            ))


def _sync_finance_assignments(db: Session, *, project_id: int, actor: User, selected_ids: set[int]) -> None:
    rows = list(db.scalars(select(FinanceProjectAssignment).where(FinanceProjectAssignment.project_id == project_id)).all())
    by_user = {row.user_id: row for row in rows}
    for row in rows:
        row.is_active = row.user_id in selected_ids
        row.assigned_by_id = actor.id
        row.updated_at = utc_now()
    for user_id in selected_ids:
        if user_id not in by_user:
            db.add(FinanceProjectAssignment(
                project_id=project_id,
                user_id=user_id,
                assigned_by_id=actor.id,
                is_active=True,
            ))


def configure_team(db: Session, *, actor: User, project_id: int, payload: WorkflowTeamSetup) -> tuple[ProjectWorkflow, dict[int, list[str]]]:
    project = _project(db, project_id)
    workflow = _workflow(db, project_id)
    if project.master_profile is None or project.master_profile.project_manager_id is None:
        raise ValueError("BD must assign the Project Manager before team selection")
    if not _is_pm(project, actor.id):
        raise PermissionError("Only the BD-assigned Ortho Project Manager can select the project team")
    if normalized_workflow_status(workflow.status) not in TEAM_SELECTION_STATUSES:
        raise ValueError(_stage_unavailable_message("Project team selection", workflow.status))

    selected = {
        "team_leader": {payload.team_leader_user_id},
        "production": set(payload.production_user_ids),
        "qc": set(payload.qc_user_ids),
        "qa": set(payload.qa_user_ids),
    }
    department_code = workflow.performing_department_code
    for role, ids in selected.items():
        if not ids:
            raise ValueError(f"Select at least one {role.replace('_', ' ')} employee")
        for user_id in ids:
            _validate_employee(db, user_id, role.replace("_", " "), department_code=department_code)
    if len(selected["team_leader"]) != 1:
        raise ValueError("Exactly one Team Lead is required")

    for role, ids in selected.items():
        _set_role_members(db, project_id=project_id, actor=actor, role=role, selected_ids=ids)

    all_employee_ids = set().union(*selected.values())
    _sync_finance_assignments(db, project_id=project_id, actor=actor, selected_ids=all_employee_ids)
    workflow.team_assigned_at = utc_now()
    next_status = WORKFLOW_IN_PROGRESS if db.scalar(select(OrthoWorkPackage.id).where(OrthoWorkPackage.project_id == project_id).limit(1)) else WORKFLOW_TEAM_ASSIGNED
    _event(db, workflow=workflow, actor=actor, event_type="pm_team_assigned", to_status=next_status)

    roles_by_user: dict[int, list[str]] = defaultdict(list)
    for role, ids in selected.items():
        for user_id in ids:
            roles_by_user[user_id].append(role)
    for user_id, roles in roles_by_user.items():
        create_global_notification(
            db,
            event_type="workflow.project.team_assignment",
            title=f"Project team assignment: {project.project_code}",
            message=f"Project ID {project.project_code} · Client ID {_client_code(project) or 'Not recorded'} · Role(s): {', '.join(role.replace('_', ' ').title() for role in roles)}.",
            category="system",
            target_url=f"/ortho?project={project.id}",
            recipient_user_ids=[user_id],
        )
    db.flush()
    return workflow, dict(roles_by_user)


# The team-confirmation history note starts with one of these; cycles confirmed before ``team_mode`` was stored are
# recognised by it, so their mode is derived (read-only) instead of the data being rewritten.
REWORK_NOTE_REUSE = "Existing team reused"
REWORK_NOTE_ADJUST = "Rework team adjusted"


def _rework_team_mode(db: Session, cycle: ProjectReworkCycle) -> str | None:
    """'reuse' | 'adjust' | None (not confirmed yet)."""
    if cycle.team_mode in {"reuse", "adjust"}:
        return cycle.team_mode
    if cycle.status == REWORK_OPEN:
        return None
    note = db.scalar(select(ProjectWorkflowEvent.comments).where(
        ProjectWorkflowEvent.project_id == cycle.project_id,
        ProjectWorkflowEvent.event_type == "rework_team_confirmed",
    ).order_by(ProjectWorkflowEvent.id.desc()).limit(1)) or ""
    if note.startswith(REWORK_NOTE_REUSE):
        return "reuse"
    if note.startswith(REWORK_NOTE_ADJUST):
        return "adjust"
    return None


def _rework_cycle_label(cycle_type: str) -> str:
    return "Approved Change Request Rework" if cycle_type == "APPROVED_CHANGE_REQUEST" else "Client Correction Rework"


def _active_rework_cycle(db: Session, project_id: int) -> ProjectReworkCycle | None:
    """The latest rework cycle that has not yet been resubmitted to / closed with the client."""
    return db.scalar(select(ProjectReworkCycle).where(
        ProjectReworkCycle.project_id == project_id,
        ProjectReworkCycle.status != REWORK_RESUBMITTED,
        ProjectReworkCycle.closed_at.is_(None),
    ).order_by(ProjectReworkCycle.cycle_number.desc()).limit(1))


def confirm_rework_team(
    db: Session, *, actor: User, cycle_id: int, payload: WorkflowReworkTeamConfirm
) -> tuple[ProjectReworkCycle, dict[int, list[str]]]:
    """Project Manager confirms the rework team: REWORK_OPEN -> REWORK_PRODUCTION.

    The original Project Manager, Project ID, original work packages and delivery history are never touched;
    ``reuse`` keeps the current team and ``adjust`` replaces the team members through the same guarded helper
    the original team selection uses.
    """
    cycle = db.get(ProjectReworkCycle, cycle_id)
    if cycle is None:
        raise ValueError("Rework cycle not found")
    project = _project(db, cycle.project_id)
    workflow = _workflow(db, cycle.project_id)
    if not _is_pm(project, actor.id):
        raise PermissionError("Only the Project Manager assigned to this project can confirm the rework team")
    if cycle.status != REWORK_OPEN or normalized_workflow_status(workflow.status) != "rework_open":
        raise ValueError("The rework team can only be confirmed while the rework cycle is Rework Open")

    current = {role: _active_member_ids(db, project_id=project.id, role=role) for role in TEAM_ROLES}
    if payload.mode == "reuse":
        selected = current
    else:
        selected = {
            "team_leader": {payload.team_leader_user_id} if payload.team_leader_user_id else set(),
            "production": set(payload.production_user_ids),
            "qc": set(payload.qc_user_ids),
            "qa": set(payload.qa_user_ids),
        }
    for role, ids in selected.items():
        label = role.replace("_", " ")
        if not ids:
            raise ValueError(
                f"There is no existing {label} to reuse; choose Adjust Rework Team and select one"
                if payload.mode == "reuse" else f"Select at least one {label} employee"
            )
        for user_id in ids:
            _validate_employee(db, user_id, label, department_code=workflow.performing_department_code)
    if len(selected["team_leader"]) != 1:
        raise ValueError("Exactly one Team Lead is required")

    if payload.mode == "adjust":
        for role, ids in selected.items():
            _set_role_members(db, project_id=project.id, actor=actor, role=role, selected_ids=ids)
        _sync_finance_assignments(db, project_id=project.id, actor=actor, selected_ids=set().union(*selected.values()))

    team_lead = db.get(User, next(iter(selected["team_leader"])))
    cycle.team_leader_user_id = team_lead.id
    cycle.team_mode = payload.mode
    if cycle.project_manager_user_id is None:
        cycle.project_manager_user_id = actor.id  # never replaced once set: the original PM stays the PM
    cycle.status = REWORK_PRODUCTION
    cycle.updated_at = utc_now()
    summary = (
        f"{REWORK_NOTE_REUSE if payload.mode == 'reuse' else REWORK_NOTE_ADJUST} · "
        f"Team Lead {team_lead.employee_id or team_lead.full_name} · Production {len(selected['production'])} · "
        f"QC {len(selected['qc'])} · QA {len(selected['qa'])}"
    )
    if (payload.remarks or "").strip():
        summary += f" · {payload.remarks.strip()}"
    lifecycle_transition(
        db,
        workflow=workflow,
        actor=actor,
        status=REWORK_PRODUCTION,
        event_type="rework_team_confirmed",
        title=f"Rework Cycle {cycle.cycle_number}: team confirmed",
        comments=summary,
    )

    roles_by_user: dict[int, list[str]] = defaultdict(list)
    for role, ids in selected.items():
        for user_id in ids:
            roles_by_user[user_id].append(role)
    for user_id, roles in roles_by_user.items():
        next_step = "Allocate the rework Area / Code / Quantity / Target Date." if user_id == team_lead.id else "Your rework task will appear after the Team Lead allocates it."
        create_global_notification(
            db,
            event_type="workflow.rework.team_confirmed",
            title=f"Rework team confirmed: {project.project_code}",
            message=(
                f"Project ID {project.project_code} · Client ID {_client_code(project) or 'Not recorded'} · "
                f"Rework Cycle {cycle.cycle_number} · Role(s): {', '.join(role.replace('_', ' ').title() for role in roles)}. {next_step}"
            ),
            category="system",
            target_url=f"/ortho?project={project.id}",
            recipient_user_ids=[user_id],
        )
    db.flush()
    return cycle, dict(roles_by_user)


def _rework_original_packages(db: Session, project_id: int) -> list[OrthoWorkPackage]:
    """Original (non-rework) work packages of a project: the possible sources a rework can carry work context from."""
    return list(db.scalars(select(OrthoWorkPackage).where(
        OrthoWorkPackage.project_id == project_id,
        OrthoWorkPackage.rework_cycle_id.is_(None),
    ).order_by(OrthoWorkPackage.id.asc())).all())


def allocate_rework_work(
    db: Session, *, actor: User, cycle_id: int, payload: WorkflowReworkAllocation
) -> OrthoWorkPackage:
    """Team Lead allocates rework work as a NEW package linked to its source (original) package.

    * ``reuse`` team (PM chose "Reuse existing team"): the source package's Code, Area, unit and Production / QC / QA
      assignees are carried forward automatically, so nothing is re-typed. The Code / Area can only be changed with a
      written correction reason. With several original packages the source must be chosen first.
    * ``adjust`` team: nothing is forced; the Team Lead enters Code / Area / assignees. A source link is optional (if
      one is given and a field is omitted it is still carried forward as a convenience).

    The source package is never modified or reopened, and the workflow status stays REWORK_PRODUCTION.
    """
    cycle = db.get(ProjectReworkCycle, cycle_id)
    if cycle is None:
        raise ValueError("Rework cycle not found")
    project = _project(db, cycle.project_id)
    workflow = _workflow(db, cycle.project_id)
    if cycle.team_leader_user_id != actor.id or not _is_team_lead(db, project_id=project.id, user_id=actor.id):
        raise PermissionError("Only the Team Lead confirmed for this rework cycle can allocate rework work")
    if cycle.status != REWORK_PRODUCTION or normalized_workflow_status(workflow.status) != "rework_production":
        raise ValueError("The Project Manager must confirm the rework team before rework work can be allocated")

    reuse = _rework_team_mode(db, cycle) == "reuse"
    originals = _rework_original_packages(db, project.id)
    source: OrthoWorkPackage | None = None
    if payload.rework_of_package_id is not None:
        source = next((pkg for pkg in originals if pkg.id == payload.rework_of_package_id), None)
        if source is None:
            raise ValueError("Select an original work package of this project to link the rework to")
    elif reuse and len(originals) > 1:
        raise ValueError("This project has more than one original work package. Select the original work package this rework is for")
    elif reuse and len(originals) == 1:
        source = originals[0]

    code = payload.package_code or (source.package_code if source else None)
    area = payload.area_name or (source.package_name if source else None)
    if not code or not area:
        raise ValueError("Code and Area are required" + (" - select the original work package to carry them forward" if originals else ""))
    unit = payload.quantity_unit or (source.area_unit if source else None) or "unit"
    if reuse and source is not None:
        changed = code.strip().lower() != source.package_code.strip().lower() or area.strip().lower() != source.package_name.strip().lower()
        if changed and not payload.correction_reason:
            raise ValueError("Code and Area are carried forward from the original work package. Enter a correction reason to change them")

    carried = {"production": source.production_user_id if source else None, "qc": source.qc_user_id if source else None, "qa": source.qa_user_id if source else None}
    assignees: dict[str, int] = {}
    for role, explicit in (("production", payload.production_user_id), ("qc", payload.qc_user_id), ("qa", payload.qa_user_id)):
        user_id = explicit
        if user_id is None:
            if carried[role] is not None and carried[role] in _active_member_ids(db, project_id=project.id, role=role):
                user_id = carried[role]
            else:
                raise ValueError(f"Select a {role} employee" + (" - the original assignee is no longer on the team" if carried[role] is not None else ""))
        _ensure_role_member(db, project_id=project.id, role=role, user_id=user_id)
        assignees[role] = user_id

    duplicate = db.scalar(select(OrthoWorkPackage.id).where(
        OrthoWorkPackage.project_id == project.id,
        OrthoWorkPackage.rework_cycle_id == cycle.id,
        func.lower(OrthoWorkPackage.package_code) == code.lower(),
    ).limit(1))
    if duplicate is not None:
        raise ValueError(f"Code {code} is already allocated in this rework cycle")
    package = OrthoWorkPackage(
        project_id=project.id,
        package_code=code,
        package_name=area,
        area=payload.quantity,
        area_unit=unit,
        target_hours=None,
        target_date=payload.target_date,
        instructions=payload.instructions,
        current_stage="not_started",
        production_state="not_started",
        qc_state="not_started",
        qa_state="not_started",
        team_leader_user_id=actor.id,
        production_user_id=assignees["production"],
        qc_user_id=assignees["qc"],
        qa_user_id=assignees["qa"],
        rework_cycle_id=cycle.id,
        rework_of_package_id=source.id if source else None,
        created_by_id=actor.id,
    )
    db.add(package)
    db.flush()
    note = f"{area} · {payload.quantity} {unit} · Target {payload.target_date.isoformat()}"
    if source is not None:
        note += f" · linked to original package {source.package_code}"
        if payload.correction_reason:
            note += f" · Code/Area correction: {payload.correction_reason}"
        elif code.strip().lower() == source.package_code.strip().lower():
            note += " · Code/Area carried forward"
    lifecycle_transition(
        db,
        workflow=workflow,
        actor=actor,
        status=REWORK_PRODUCTION,
        event_type="rework_work_allocated",
        title=f"Rework Cycle {cycle.cycle_number}: work allocated ({code})",
        comments=note,
    )
    for role, user_id in assignees.items():
        create_global_notification(
            db,
            event_type="workflow.rework.work_assigned",
            title=f"New REWORK {role.upper()} work: {code}",
            message=(
                f"Project ID {project.project_code} · Client ID {_client_code(project) or 'Not recorded'} · Rework Cycle {cycle.cycle_number} · "
                f"Area {area} · Code {code} · {payload.quantity} {unit} · Target {payload.target_date.isoformat()}."
            ),
            category="system",
            target_url=f"/ortho?project={project.id}",
            recipient_user_ids=[user_id],
        )
    db.flush()
    return package


def _rework_context(db: Session, *, project: FinanceProject, actor: User, status_key: str, viewer_is_pm: bool, all_packages: list[OrthoWorkPackage]) -> dict | None:
    cycle = _active_rework_cycle(db, project.id)
    if cycle is None:
        return None
    response = db.get(ProjectFeedbackResponse, cycle.source_feedback_response_id)
    change_request = db.get(ProjectChangeRequest, cycle.source_change_request_id) if cycle.source_change_request_id else None
    pm = _pm(project)
    team_lead = db.get(User, cycle.team_leader_user_id) if cycle.team_leader_user_id else None
    originals = [pkg for pkg in all_packages if pkg.rework_cycle_id is None]
    user_ids = {uid for pkg in originals for uid in (pkg.team_leader_user_id, pkg.production_user_id, pkg.qc_user_id, pkg.qa_user_id) if uid}
    names = {u.id: u.full_name for u in db.scalars(select(User).where(User.id.in_(user_ids))).all()} if user_ids else {}
    on_team = {role: _active_member_ids(db, project_id=project.id, role=role) for role in ("production", "qc", "qa")}
    return {
        "cycle_id": cycle.id,
        "cycle_number": cycle.cycle_number,
        "cycle_type": cycle.cycle_type,
        "cycle_label": _rework_cycle_label(cycle.cycle_type),
        "status": cycle.status,
        "team_mode": _rework_team_mode(db, cycle),
        "reason": cycle.correction_scope,
        "client_feedback": ((response.correction_description or response.comments) if response else None),
        "change_request_code": change_request.request_code if change_request else None,
        "project_manager_name": pm.full_name if pm else None,
        "team_leader_id": cycle.team_leader_user_id,
        "team_leader_name": team_lead.full_name if team_lead else None,
        "can_confirm_team": bool(viewer_is_pm and cycle.status == REWORK_OPEN and status_key == "rework_open"),
        "can_allocate": bool(cycle.team_leader_user_id == actor.id and cycle.status == REWORK_PRODUCTION and status_key == "rework_production"),
        # Possible source packages, with the work context a reused team carries forward.
        "original_packages": [
            {
                "id": pkg.id,
                "package_code": pkg.package_code,
                "area_name": pkg.package_name,
                "quantity": float(pkg.area) if pkg.area is not None else None,
                "quantity_unit": pkg.area_unit,
                "current_stage": pkg.current_stage,
                "team_leader_user_id": pkg.team_leader_user_id,
                "team_leader_name": names.get(pkg.team_leader_user_id),
                "production_user_id": pkg.production_user_id,
                "production_name": names.get(pkg.production_user_id),
                "qc_user_id": pkg.qc_user_id,
                "qc_name": names.get(pkg.qc_user_id),
                "qa_user_id": pkg.qa_user_id,
                "qa_name": names.get(pkg.qa_user_id),
                # False when the original assignee is no longer on the (current) team: the Team Lead must pick one.
                "carry_forward": {
                    "production": pkg.production_user_id in on_team["production"],
                    "qc": pkg.qc_user_id in on_team["qc"],
                    "qa": pkg.qa_user_id in on_team["qa"],
                },
            }
            for pkg in originals
        ],
    }


def _annotate_rework_packages(db: Session, project_id: int, payloads: list[dict], packages: list[OrthoWorkPackage], all_packages: list[OrthoWorkPackage]) -> None:
    numbers = {int(row.id): int(row.cycle_number) for row in db.scalars(select(ProjectReworkCycle).where(ProjectReworkCycle.project_id == project_id)).all()}
    codes = {pkg.id: pkg.package_code for pkg in all_packages}
    for payload, pkg in zip(payloads, packages):
        payload["rework_cycle_id"] = pkg.rework_cycle_id
        payload["rework_cycle_number"] = numbers.get(pkg.rework_cycle_id) if pkg.rework_cycle_id else None
        payload["rework_of_package_code"] = codes.get(pkg.rework_of_package_id) if pkg.rework_of_package_id else None


def email_team_assignments(db: Session, *, project_id: int, roles_by_user: dict[int, list[str]]) -> None:
    project = _project(db, project_id)
    tl_ids = _active_member_ids(db, project_id=project_id, role="team_leader")
    team_lead = db.get(User, next(iter(tl_ids))) if tl_ids else None
    for user_id, roles in roles_by_user.items():
        user = db.get(User, user_id)
        if user is None:
            continue
        _safe_send_email(
            recipient=user.email,
            subject=f"[{project.project_code}] Project team assignment",
            body=(
                f"Hello {user.full_name},\n\n"
                "You have been selected for an Ortho project in Nakshatech ERP.\n\n"
                f"Project ID: {project.project_code}\n"
                f"Client ID: {_client_code(project) or 'Not recorded'}\n"
                f"Role(s): {', '.join(role.replace('_', ' ').title() for role in roles)}\n"
                f"Team Lead: {(team_lead.employee_id or team_lead.full_name) if team_lead else 'Not assigned'}\n"
                f"Start Date: {project.start_date.isoformat() if project.start_date else 'Not recorded'}\n"
                f"End Date: {project.end_date.isoformat() if project.end_date else 'Not recorded'}\n\n"
                "Your exact Area / Code / Quantity task will appear after the Team Lead allocates it.\n"
                f"ERP Dashboard: {settings.app_public_url.rstrip('/')}/ortho\n\n"
                "Nakshatech ERP"
            ),
            from_name="Nakshatech Ortho",
        )


def _member_roles(db: Session, *, project_id: int, user_id: int) -> set[str]:
    return set(db.scalars(select(OrthoProjectMember.member_role).where(
        OrthoProjectMember.project_id == project_id,
        OrthoProjectMember.user_id == user_id,
        OrthoProjectMember.is_active.is_(True),
    )).all())


def _is_team_lead(db: Session, *, project_id: int, user_id: int) -> bool:
    return "team_leader" in _member_roles(db, project_id=project_id, user_id=user_id)


def _ensure_role_member(db: Session, *, project_id: int, role: str, user_id: int) -> None:
    exists = db.scalar(select(OrthoProjectMember.id).where(
        OrthoProjectMember.project_id == project_id,
        OrthoProjectMember.member_role == role,
        OrthoProjectMember.user_id == user_id,
        OrthoProjectMember.is_active.is_(True),
    ).limit(1))
    if exists is None:
        raise ValueError(f"The selected {role.replace('_', ' ')} employee was not selected by the Project Manager")


def allocate_work(db: Session, *, actor: User, project_id: int, payload: WorkflowWorkAllocation) -> OrthoWorkPackage:
    workflow = _workflow(db, project_id)
    if not _is_team_lead(db, project_id=project_id, user_id=actor.id):
        raise PermissionError("Only the Project Manager-selected Team Lead can distribute Area / Code / Quantity work")
    if normalized_workflow_status(workflow.status) not in WORK_ALLOCATION_STATUSES:
        if normalized_workflow_status(workflow.status) in {WORKFLOW_FINANCE_APPROVED, WORKFLOW_PM_ASSIGNED}:
            raise ValueError("The Project Manager must select the project team before work allocation")
        raise ValueError(_stage_unavailable_message("Work allocation", workflow.status))
    _ensure_role_member(db, project_id=project_id, role="production", user_id=payload.production_user_id)
    _ensure_role_member(db, project_id=project_id, role="qc", user_id=payload.qc_user_id)
    _ensure_role_member(db, project_id=project_id, role="qa", user_id=payload.qa_user_id)
    duplicate = db.scalar(select(OrthoWorkPackage.id).where(
        OrthoWorkPackage.project_id == project_id,
        func.lower(OrthoWorkPackage.package_code) == payload.package_code.lower(),
    ).limit(1))
    if duplicate is not None:
        raise ValueError(f"Code {payload.package_code} already exists in this project")
    package = OrthoWorkPackage(
        project_id=project_id,
        package_code=payload.package_code,
        package_name=payload.area_name,
        area=payload.quantity,
        area_unit=payload.quantity_unit,
        target_hours=None,
        target_date=payload.target_date,
        instructions=payload.instructions,
        current_stage="not_started",
        production_state="not_started",
        qc_state="not_started",
        qa_state="not_started",
        team_leader_user_id=actor.id,
        production_user_id=payload.production_user_id,
        qc_user_id=payload.qc_user_id,
        qa_user_id=payload.qa_user_id,
        created_by_id=actor.id,
    )
    db.add(package)
    _event(db, workflow=workflow, actor=actor, event_type="team_lead_work_allocated", to_status=WORKFLOW_IN_PROGRESS, comments=payload.package_code)
    db.flush()
    project = _project(db, project_id)
    for role, user_id in (("production", payload.production_user_id), ("qc", payload.qc_user_id), ("qa", payload.qa_user_id)):
        create_global_notification(
            db,
            event_type="workflow.work.assigned",
            title=f"New {role.upper()} work: {payload.package_code}",
            message=(
                f"Project ID {project.project_code} · Client ID {_client_code(project) or 'Not recorded'} · "
                f"Area {payload.area_name} · Code {payload.package_code} · {payload.quantity} {payload.quantity_unit} · Target {payload.target_date.isoformat()}."
            ),
            category="system",
            target_url=f"/ortho?project={project.id}",
            recipient_user_ids=[user_id],
            # Actionable, and ASSIGNMENT-scoped: only the assigned user is a recipient.
            # A different Production/QC/QA user must never receive it.
            severity="warning",
            requires_action=True,
            metadata={
                "project_name": project.project_code,
                "package_code": payload.package_code,
                "assigned_role": role.upper(),
                "area": payload.area_name,
                "target_date": payload.target_date.isoformat() if payload.target_date else None,
            },
        )
    db.flush()
    return package


def email_work_allocation(db: Session, *, work_package_id: int) -> None:
    package = db.get(OrthoWorkPackage, work_package_id)
    if package is None:
        return
    project = _project(db, package.project_id)
    for role, user_id in (("Production", package.production_user_id), ("QC", package.qc_user_id), ("QA", package.qa_user_id)):
        if not user_id:
            continue
        user = db.get(User, user_id)
        if user is None:
            continue
        _safe_send_email(
            recipient=user.email,
            subject=f"[{project.project_code}] New {role} work - {package.package_code}",
            body=(
                f"Hello {user.full_name},\n\n"
                "New work has been assigned to you.\n\n"
                f"Project ID: {project.project_code}\n"
                f"Client ID: {_client_code(project) or 'Not recorded'}\n"
                f"Role: {role}\n"
                f"Area: {package.package_name}\n"
                f"Code: {package.package_code}\n"
                f"Assigned Quantity: {package.area} {package.area_unit}\n"
                f"Target Date: {package.target_date.isoformat() if package.target_date else 'Not recorded'}\n\n"
                f"Instructions: {package.instructions or 'Not recorded'}\n\n"
                f"ERP Dashboard: {settings.app_public_url.rstrip('/')}/ortho\n\n"
                "Nakshatech ERP"
            ),
            from_name="Nakshatech Team Lead",
        )


def _daily_totals(package: OrthoWorkPackage) -> tuple[Decimal, int]:
    quantity = sum((row.achieved_area or Decimal("0")) for row in package.daily_updates)
    files = sum(int(row.files_completed or 0) for row in package.daily_updates)
    return quantity, files


def _package_query():
    return select(OrthoWorkPackage).options(
        selectinload(OrthoWorkPackage.daily_updates),
        selectinload(OrthoWorkPackage.reviews),
        selectinload(OrthoWorkPackage.sessions),
    )


def package_by_id(db: Session, work_package_id: int) -> OrthoWorkPackage:
    package = db.scalar(_package_query().where(OrthoWorkPackage.id == work_package_id))
    if package is None:
        raise ValueError("Work package not found")
    return package


def record_daily_activity(db: Session, *, actor: User, work_package_id: int, payload: WorkflowDailyActivity) -> OrthoDailyUpdate:
    package = package_by_id(db, work_package_id)
    if package.production_user_id != actor.id:
        raise PermissionError("Only the Production employee assigned to this exact task can submit Daily Activity")
    if package.current_stage not in {"not_started", "production", "production_rework"}:
        raise ValueError("Daily Activity is available only while Production work is active")
    current, _ = _daily_totals(package)
    incoming = payload.quantity_completed
    if package.current_stage != "production_rework" and incoming <= 0:
        raise ValueError("Today's completed quantity must be greater than zero")
    target = package.area or Decimal("0")
    new_total = current + incoming
    if package.current_stage != "production_rework" and target > 0 and new_total > target:
        raise ValueError(f"Daily quantity would exceed the assigned quantity. Remaining: {target - current} {package.area_unit}")
    if package.current_stage == "not_started":
        package.current_stage = "production"
        package.production_state = "running"
    progress = Decimal("0") if target <= 0 else min(Decimal("100"), (new_total / target) * Decimal("100"))
    row = OrthoDailyUpdate(
        work_package_id=package.id,
        update_date=payload.update_date or date.today(),
        work_type=payload.work_type,
        achieved_area=incoming,
        progress_percent=progress.quantize(Decimal("0.01")),
        files_completed=payload.files_completed,
        hours_spent=payload.hours_spent,
        status=payload.status,
        blockers=(payload.blockers or "").strip() or None,
        remarks=(payload.remarks or "").strip() or None,
        updated_by_id=actor.id,
    )
    db.add(row)
    db.flush()
    return row


def _sync_rework_cycle(db: Session, *, actor: User, package: OrthoWorkPackage, note: str, delivery_reference: str | None = None) -> None:
    """A rework package's Production / QC / QA / Delivery events move its rework cycle (and the project lifecycle status)
    through the authoritative rework lifecycle. No-op for ordinary (original) work packages."""
    if package.rework_cycle_id is not None:
        db.flush()
        sync_rework_cycle_with_packages(db, actor=actor, cycle_id=package.rework_cycle_id, note=note, delivery_reference=delivery_reference)


def complete_production(db: Session, *, actor: User, work_package_id: int) -> OrthoWorkPackage:
    package = package_by_id(db, work_package_id)
    if package.production_user_id != actor.id:
        raise PermissionError("Only the Production employee assigned to this exact task can complete Production")
    total, _ = _daily_totals(package)
    target = package.area or Decimal("0")
    if package.current_stage != "production_rework" and target > 0 and total < target:
        raise ValueError(f"Complete the remaining {target - total} {package.area_unit} before finishing Production")
    if package.qc_user_id is None:
        raise ValueError("QC employee is not assigned")
    package.production_state = "completed"
    package.production_completed_at = utc_now()
    package.current_stage = "qc"
    package.qc_state = "pending"
    package.qc_submitted_at = utc_now()
    project = _project(db, package.project_id)
    pm = _pm(project)
    recipients = [uid for uid in {package.team_leader_user_id, package.qc_user_id, pm.id if pm else None} if uid]
    create_global_notification(
        db,
        event_type="workflow.production.completed",
        title=f"Production completed: {package.package_code}",
        message=f"Project ID {project.project_code} · Code {package.package_code} is ready for QC.",
        category="system",
        target_url=f"/ortho?project={project.id}",
        recipient_user_ids=recipients,
    )
    db.flush()
    _sync_rework_cycle(db, actor=actor, package=package, note=f"Production completed: {package.package_code}")
    return package


def email_production_completion(db: Session, *, work_package_id: int) -> None:
    package = package_by_id(db, work_package_id)
    project = _project(db, package.project_id)
    pm = _pm(project)
    recipient_ids = {uid for uid in [package.team_leader_user_id, package.qc_user_id, pm.id if pm else None] if uid}
    for user_id in recipient_ids:
        user = db.get(User, user_id)
        if user is None:
            continue
        _safe_send_email(
            recipient=user.email,
            subject=f"[{project.project_code}] Production complete - {package.package_code}",
            body=(
                f"Hello {user.full_name},\n\n"
                f"Production is complete for the assigned work item.\n\n"
                f"Project ID: {project.project_code}\n"
                f"Client ID: {_client_code(project) or 'Not recorded'}\n"
                f"Area: {package.package_name}\n"
                f"Code: {package.package_code}\n"
                "Status: Ready for QC\n\n"
                f"ERP Dashboard: {settings.app_public_url.rstrip('/')}/ortho\n\n"
                "Nakshatech ERP"
            ),
            from_name="Nakshatech Production",
        )


def email_review_transition(db: Session, *, work_package_id: int, kind: str, decision: str) -> None:
    package = package_by_id(db, work_package_id)
    project = _project(db, package.project_id)
    pm = _pm(project)
    kind = kind.lower()
    decision = decision.lower()
    if kind == "qc" and decision == "approve":
        recipient_ids = {package.qa_user_id}
        headline = "QC approved - ready for QA"
    elif kind == "qc":
        recipient_ids = {package.production_user_id, package.team_leader_user_id, pm.id if pm else None}
        headline = "QC rejected - Production rework required"
    elif decision == "approve":
        recipient_ids = {package.team_leader_user_id, pm.id if pm else None}
        headline = "QA approved - ready for Delivery"
    else:
        recipient_ids = {package.production_user_id, package.team_leader_user_id, pm.id if pm else None}
        headline = "QA rejected - Production rework required"
    for user_id in {uid for uid in recipient_ids if uid}:
        user = db.get(User, user_id)
        if user is None:
            continue
        _safe_send_email(
            recipient=user.email,
            subject=f"[{project.project_code}] {headline} - {package.package_code}",
            body=(
                f"Hello {user.full_name},\n\n"
                f"{headline}.\n\n"
                f"Project ID: {project.project_code}\n"
                f"Client ID: {_client_code(project) or 'Not recorded'}\n"
                f"Area: {package.package_name}\n"
                f"Code: {package.package_code}\n\n"
                f"ERP Dashboard: {settings.app_public_url.rstrip('/')}/ortho\n\n"
                "Nakshatech ERP"
            ),
            from_name=f"Nakshatech {kind.upper()}",
        )


def email_delivery_completion(db: Session, *, work_package_id: int) -> None:
    package = package_by_id(db, work_package_id)
    project = _project(db, package.project_id)
    pm = _pm(project)
    for user_id in {uid for uid in [package.team_leader_user_id, pm.id if pm else None] if uid}:
        user = db.get(User, user_id)
        if user is None:
            continue
        _safe_send_email(
            recipient=user.email,
            subject=f"[{project.project_code}] Delivered - {package.package_code}",
            body=(
                f"Hello {user.full_name},\n\n"
                f"Project ID: {project.project_code}\n"
                f"Client ID: {_client_code(project) or 'Not recorded'}\n"
                f"Area: {package.package_name}\n"
                f"Code: {package.package_code}\n"
                "Status: Delivered\n\n"
                f"ERP Dashboard: {settings.app_public_url.rstrip('/')}/ortho\n\n"
                "Nakshatech ERP"
            ),
            from_name="Nakshatech Delivery",
        )


def _review_attempt(db: Session, package_id: int, kind: str) -> int:
    current = db.scalar(select(func.max(OrthoReview.attempt_no)).where(
        OrthoReview.work_package_id == package_id,
        OrthoReview.review_type == kind,
    ))
    return int(current or 0) + 1


def review_work(db: Session, *, actor: User, work_package_id: int, kind: str, payload: WorkflowReviewRequest) -> OrthoWorkPackage:
    package = package_by_id(db, work_package_id)
    kind = kind.lower()
    if payload.decision == "reject" and not (payload.comments or "").strip():
        raise ValueError(f"{kind.upper()} rejection comments are required for rework")
    if kind == "qc":
        if package.qc_user_id != actor.id:
            raise PermissionError("Only the QC employee assigned to this exact task can record the QC decision")
        if package.current_stage != "qc" or package.qc_state != "pending":
            raise ValueError("This task is not waiting for QC")
    elif kind == "qa":
        if package.qa_user_id != actor.id:
            raise PermissionError("Only the QA employee assigned to this exact task can record the QA decision")
        if package.current_stage != "qa" or package.qa_state != "pending":
            raise ValueError("This task is not waiting for QA")
    else:
        raise ValueError("Review type must be QC or QA")

    db.add(OrthoReview(
        work_package_id=package.id,
        review_type=kind,
        attempt_no=_review_attempt(db, package.id, kind),
        reviewer_user_id=actor.id,
        decision=payload.decision,
        comments=(payload.comments or "").strip() or None,
    ))
    project = _project(db, package.project_id)
    pm = _pm(project)
    if kind == "qc" and payload.decision == "approve":
        package.qc_state = "approved"
        package.current_stage = "qa"
        package.qa_state = "pending"
        package.qa_submitted_at = utc_now()
        recipients = [package.qa_user_id]
        event_type = "workflow.qc.approved"
        title = f"QC approved: {package.package_code}"
        message = f"Project ID {project.project_code} · Code {package.package_code} is ready for QA."
    elif kind == "qc":
        package.qc_state = "rejected"
        package.current_stage = "production_rework"
        package.production_state = "rework_required"
        package.rework_source = "qc"
        recipients = [package.production_user_id, package.team_leader_user_id, pm.id if pm else None]
        event_type = "workflow.qc.rejected"
        title = f"QC rework required: {package.package_code}"
        message = f"Project ID {project.project_code} · Code {package.package_code} returned to Production. {payload.comments or ''}".strip()
    elif payload.decision == "approve":
        package.qa_state = "approved"
        package.current_stage = "delivery_ready"
        package.delivery_ready_at = utc_now()
        package.rework_source = None
        recipients = [package.team_leader_user_id, pm.id if pm else None]
        event_type = "workflow.qa.approved"
        title = f"Ready for delivery: {package.package_code}"
        message = f"Project ID {project.project_code} · Code {package.package_code} passed QA and is Ready for Delivery."
    else:
        package.qa_state = "rejected"
        package.current_stage = "production_rework"
        package.production_state = "rework_required"
        package.rework_source = "qa"
        recipients = [package.production_user_id, package.team_leader_user_id, pm.id if pm else None]
        event_type = "workflow.qa.rejected"
        title = f"QA rework required: {package.package_code}"
        message = f"Project ID {project.project_code} · Code {package.package_code} returned to Production. {payload.comments or ''}".strip()
    create_global_notification(
        db,
        event_type=event_type,
        title=title,
        message=message,
        category="system",
        target_url=f"/ortho?project={project.id}",
        recipient_user_ids=[uid for uid in recipients if uid],
    )
    db.flush()
    verdict = "approved" if payload.decision == "approve" else f"rejected - {(payload.comments or '').strip()}"
    _sync_rework_cycle(db, actor=actor, package=package, note=f"{kind.upper()} {verdict}: {package.package_code}")
    return package


def mark_delivered(db: Session, *, actor: User, work_package_id: int, payload: WorkflowDeliveryRequest) -> OrthoWorkPackage:
    package = package_by_id(db, work_package_id)
    project = _project(db, package.project_id)
    if not (_is_pm(project, actor.id) or package.team_leader_user_id == actor.id):
        raise PermissionError("Only the Team Lead or Project Manager can record Delivery")
    # File-tracked areas: readiness comes from the authoritative physical files (all files
    # must have passed QA) AND the explicit Ready-for-Delivery confirmation. Legacy areas
    # keep the original stage/qa_state gate unchanged.
    readiness = delivery_readiness(db, package)
    if readiness["applicable"]:
        if not readiness["ready"]:
            raise ValueError(
                "Not all files passed QA yet — QA must approve every required file before Delivery"
            )
        if package.ready_for_delivery_at is None:
            raise ValueError("Confirm Ready for Delivery before recording Delivery")
    elif package.current_stage != "delivery_ready" or package.qa_state != "approved":
        raise ValueError("QA must approve the task before Delivery")
    if package.current_stage == "delivered":
        raise ValueError("This area is already delivered")
    if readiness["applicable"]:
        # Keep ONE source of truth: record the delivery on each physical file so the
        # file-tracked counters/readiness/stage bucket all agree with the area state.
        from app.modules.operations import production_items as _items
        item_rows = _items.items_for_packages(db, [package.id])
        latest = _items.latest_activities_by_item(db, [package.id])
        for item in item_rows:
            if not item.is_active:
                continue
            delivery = latest.get(item.id, {}).get("delivery")
            if delivery is not None and delivery.status == "delivered":
                continue
            _items.deliver_item(
                db, actor=actor,
                role=("project_manager" if _is_pm(project, actor.id) else "employee"),
                work_package_item_id=item.id,
                remarks=(payload.remarks or "").strip() or None,
                reference=None,
            )
    package.current_stage = "delivered"
    package.delivered_at = utc_now()
    pm = _pm(project)
    create_global_notification(
        db,
        event_type="workflow.delivery.completed",
        title=f"Delivered: {package.package_code}",
        message=f"Project ID {project.project_code} · Code {package.package_code} has been delivered.",
        category="system",
        target_url=f"/ortho?project={project.id}",
        recipient_user_ids=[uid for uid in {package.team_leader_user_id, pm.id if pm else None} if uid],
    )
    db.flush()
    _sync_rework_cycle(db, actor=actor, package=package, note=f"Delivered: {package.package_code}", delivery_reference=(payload.remarks or "").strip() or None)
    return package


def operational_complete(db: Session, *, actor: User, project_id: int, payload: WorkflowOperationalCompletion) -> ProjectWorkflow:
    project = _project(db, project_id)
    workflow = _workflow(db, project_id)
    if not _is_pm(project, actor.id):
        raise PermissionError("Only the BD-assigned Project Manager can confirm Operational Completion")
    if normalized_workflow_status(workflow.status) not in {WORKFLOW_TEAM_ASSIGNED, WORKFLOW_IN_PROGRESS}:
        # Completion opens the BD feedback or Management approval lifecycle. Repeating it
        # over approval, rework, feedback or billing would discard the existing state.
        raise ValueError("Operational Completion is only available while the project is In Progress")
    packages = list(db.scalars(select(OrthoWorkPackage).where(OrthoWorkPackage.project_id == project_id)).all())
    if not packages:
        raise ValueError("Create and complete at least one work allocation before Project Completion")
    # File-tracked areas derive their effective stage from the item rollups (one source of
    # truth); legacy areas keep the package-level stage column.
    item_contexts = item_dashboard_context(db, packages)

    def _effective_stage(pkg: OrthoWorkPackage) -> str | None:
        ctx = item_contexts.get(pkg.id) or {}
        if ctx.get("has_items"):
            return ctx.get("stage_bucket") or pkg.current_stage
        return pkg.current_stage

    blocking = [pkg.package_code for pkg in packages if _effective_stage(pkg) != "delivered"]
    if blocking:
        raise ValueError("All assigned work must be delivered before Project Completion: " + ", ".join(blocking[:10]))
    workflow.operational_completed_at = utc_now()
    workflow.completion_date = payload.completion_date
    workflow.final_delivery_reference = (payload.final_delivery_reference or "").strip() or None
    workflow.completion_remarks = (payload.remarks or "").strip() or None
    enter_feedback_lifecycle(db, actor=actor, project=project, workflow=workflow)
    if project.master_profile:
        # Operational completion is no longer financial/project closure. Keep the
        # authoritative project visible until feedback, billing and payment finish.
        project.master_profile.project_status = "active"
        project.master_profile.updated_by_id = actor.id
        project.master_profile.updated_at = utc_now()
    project.is_active = True
    profile = db.get(OrthoProjectProfile, project_id)
    if profile:
        profile.status = (
            "awaiting_management_approval"
            if db.get(ManagementProjectLink, project_id) is not None
            else "awaiting_client_feedback"
        )
        profile.final_delivery_at = workflow.operational_completed_at
        profile.final_delivery_by_id = actor.id
        profile.final_delivery_remarks = workflow.completion_remarks
    db.flush()
    return workflow


def email_operational_completion(db: Session, *, project_id: int) -> None:
    project = _project(db, project_id)
    workflow = _workflow(db, project_id)
    recipients = resolve_recipient_users(db, recipient_roles=[FINANCE_ROLE])
    owner = db.get(User, workflow.bd_owner_user_id)
    if owner:
        recipients = [*recipients, owner]
    is_management = db.get(ManagementProjectLink, project_id) is not None
    next_step = (
        "The original Management source must approve this delivery before Finance can invoice.\n"
        f"ERP: {settings.app_public_url.rstrip('/')}/management/client-register\n"
        if is_management else
        "The project is now waiting for a secure Client Feedback Request. "
        "Finance Closure is unavailable until acceptance, invoicing and payment are complete.\n"
        f"ERP: {settings.app_public_url.rstrip('/')}/bd/feedback\n"
    )
    seen: set[int] = set()
    for user in recipients:
        if user.id in seen:
            continue
        seen.add(user.id)
        _safe_send_email(
            recipient=user.email,
            subject=f"[{project.project_code}] Operational completion",
            body=(
                f"Hello {user.full_name},\n\n"
                f"Project ID {project.project_code} has completed operational delivery.\n"
                f"Client ID: {_client_code(project) or 'Not recorded'}\n"
                f"Completion Date: {workflow.completion_date.isoformat() if workflow.completion_date else 'Not recorded'}\n"
                f"Delivery Reference: {workflow.final_delivery_reference or 'Not recorded'}\n\n"
                f"{next_step}\n"
                "Nakshatech ERP"
            ),
            from_name="Nakshatech Operations",
        )


def finance_close_project(db: Session, *, actor: User, project_id: int, payload: WorkflowFinanceClosure) -> ProjectWorkflow:
    workflow = _workflow(db, project_id)
    legacy_closure = workflow.status == WORKFLOW_FINANCE_CLOSURE_PENDING
    assert_finance_closable(db, workflow=workflow)
    project = _project(db, project_id)
    # Finance's authorized project closure also finalizes invoices whose balance
    # is resolved by approved Bad Debt. Approval by itself never closes them.
    for invoice in db.scalars(select(ProjectInvoice).where(ProjectInvoice.project_id == project_id)).all():
        if invoice.status != "INVOICE_CLOSED":
            close_invoice(db, actor=actor, invoice_id=invoice.id, payload=InvoiceClose(comments=payload.remarks))
    workflow.finance_closed_at = utc_now()
    workflow.finance_closure_remarks = payload.remarks.strip()
    _event(
        db,
        workflow=workflow,
        actor=actor,
        event_type="finance_closed_project",
        to_status=WORKFLOW_CLOSED if legacy_closure else LIFECYCLE_CLOSED,
        comments=payload.remarks,
    )
    if not legacy_closure:
        record_project_closed_timeline(db, actor=actor, project_id=project_id, remarks=payload.remarks)
    if project.master_profile:
        project.master_profile.project_status = "completed"
        project.master_profile.updated_by_id = actor.id
        project.master_profile.updated_at = utc_now()
    project.is_active = False
    profile = db.get(OrthoProjectProfile, project_id)
    if profile:
        profile.status = "closed"
    pm = _pm(project)
    recipients = [workflow.bd_owner_user_id]
    if pm:
        recipients.append(pm.id)
    create_global_notification(
        db,
        event_type="workflow.project.closed",
        title=f"Project closed: {project.project_code}",
        message=f"Finance Closure is complete for Project ID {project.project_code}.",
        category="system",
        target_url=f"/bd/projects?project={project.id}",
        recipient_user_ids=recipients,
    )
    db.flush()
    return workflow


def email_finance_closure(db: Session, *, project_id: int) -> None:
    project = _project(db, project_id)
    workflow = _workflow(db, project_id)
    recipients: list[User] = []
    owner = db.get(User, workflow.bd_owner_user_id)
    pm = _pm(project)
    if owner is not None:
        recipients.append(owner)
    if pm is not None and all(existing.id != pm.id for existing in recipients):
        recipients.append(pm)
    for user in recipients:
        _safe_send_email(
            recipient=user.email,
            subject=f"[{project.project_code}] Finance Closure complete",
            body=(
                f"Hello {user.full_name},\n\n"
                f"Finance Closure is complete for Project ID {project.project_code}.\n"
                f"Client ID: {_client_code(project) or 'Not recorded'}\n"
                f"Closure Remarks: {workflow.finance_closure_remarks or 'Not recorded'}\n\n"
                "Final Status: CLOSED\n\n"
                f"ERP: {settings.app_public_url.rstrip('/')}\n\n"
                "Nakshatech ERP"
            ),
            from_name="Nakshatech Finance",
        )


def _member_map(db: Session, project_id: int) -> list[dict]:
    rows = list(db.scalars(select(OrthoProjectMember).where(
        OrthoProjectMember.project_id == project_id,
        OrthoProjectMember.member_role.in_(TEAM_ROLES),
        OrthoProjectMember.is_active.is_(True),
    ).order_by(OrthoProjectMember.member_role.asc(), OrthoProjectMember.id.asc())).all())
    users = {u.id: u for u in db.scalars(select(User).where(User.id.in_({row.user_id for row in rows}))).all()} if rows else {}
    return [
        {
            "user_id": row.user_id,
            "employee_id": users[row.user_id].employee_id if row.user_id in users else None,
            "full_name": users[row.user_id].full_name if row.user_id in users else None,
            "email": users[row.user_id].email if row.user_id in users else None,
            "member_role": row.member_role,
        }
        for row in rows
    ]


def _package_payload(
    db: Session,
    package: OrthoWorkPackage,
    *,
    viewer: User,
    viewer_is_pm: bool,
    viewer_is_tl: bool,
    item_ctx: dict | None = None,
) -> dict:
    total, files = _daily_totals(package)
    item_ctx = item_ctx or {"has_items": False}
    has_items = bool(item_ctx.get("has_items"))
    _item_expected = int(item_ctx.get("active_count") or 0)
    target = package.area or Decimal("0")
    if has_items:
        # File-based area: the authoritative figures are the item rollups (same source
        # as Production Tracking) — never the legacy area-level daily updates.
        total = Decimal(str(item_ctx.get("production_actual", 0.0)))
        files = int(item_ctx.get("active_count", 0))
    remaining = max(Decimal("0"), target - total)
    progress = 0.0 if target <= 0 else min(100.0, float((total / target) * Decimal("100")))
    # V8.1 production tracking (additive): over-target variance + workflow % derived
    # from the applicable department stage profile (never user-typed).
    production_math = package_production_progress(total, package.area)
    department_code = db.scalar(select(ProjectWorkflow.performing_department_code).where(ProjectWorkflow.project_id == package.project_id)) or "ortho"
    applicable_stages = stage_profile_for_department(department_code)
    can_edit_general = viewer_is_pm or viewer_is_tl
    stage_updates: dict[str, dict] = {}
    actor_is_production = package.production_user_id == viewer.id
    actor_is_dxf = package.dxf_user_id is not None and package.dxf_user_id == viewer.id
    for stage in TRACKABLE_STAGES:
        if stage not in applicable_stages:
            continue
        allowed = can_edit_general or actor_is_production or (stage == "dxf" and actor_is_dxf)
        stage_updates[stage] = {
            "label": STAGE_LABELS.get(stage, stage),
            "status": getattr(package, STAGE_STATUS_ATTR[stage], None),
            "statuses": list(STAGE_STATUSES[stage]),
            "can_update": allowed,
        }
    my_roles = []
    if package.team_leader_user_id == viewer.id:
        my_roles.append("team_leader")
    if package.production_user_id == viewer.id:
        my_roles.append("production")
    if package.qc_user_id == viewer.id:
        my_roles.append("qc")
    if package.qa_user_id == viewer.id:
        my_roles.append("qa")
    if has_items:
        # File-level assignment is authoritative when the area tracks files.
        active_item_rows = [row for row in item_ctx["rows"] if row["is_active"]]
        for stage_name, id_key in (
            ("production", "production_user_id"),
            ("qc", "qc_user_id"),
            ("qa", "qa_user_id"),
        ):
            if stage_name not in my_roles and any(row.get(id_key) == viewer.id for row in active_item_rows):
                my_roles.append(stage_name)

    updates = package.daily_updates
    if not (viewer_is_pm or viewer_is_tl):
        updates = [row for row in updates if row.updated_by_id == viewer.id]
    payload = {
        "id": package.id,
        "package_code": package.package_code,
        "area_name": package.package_name,
        "quantity": float(package.area) if package.area is not None else None,
        "quantity_unit": package.area_unit,
        "target_date": package.target_date.isoformat() if package.target_date else None,
        "instructions": package.instructions,
        "current_stage": package.current_stage,
        # Displayed stage for the UI: file-tracked areas show the derived physical-file
        # stage (never the stale legacy column), legacy areas keep current_stage.
        "display_stage": package.current_stage,
        # Delivery lifecycle flags (legacy semantics; overridden for file-tracked areas below).
        "ready_eligible": package.current_stage == "delivery_ready",
        "ready_for_delivery": package.current_stage == "delivery_ready",
        "delivered": package.current_stage == "delivered",
        "delivered_at": package.delivered_at.isoformat() if package.delivered_at else None,
        "production_state": package.production_state,
        "qc_state": package.qc_state,
        "qa_state": package.qa_state,
        "rework_source": package.rework_source,
        "cumulative_completed": float(total),
        "remaining_quantity": float(remaining),
        "progress_percent": round(progress, 2),
        "over_target_quantity": float(production_math["over_target_quantity"]),
        "workflow_progress_percent": package_workflow_progress(package, department_code, item_ctx),
        "applicable_stages": [
            {"code": stage, "label": STAGE_LABELS.get(stage, stage), "status": stage_status(package, stage)}
            for stage in applicable_stages
        ],
        "stage_updates": stage_updates,
        "lot_batch": package.lot_batch,
        "supply_date": package.supply_date.isoformat() if package.supply_date else None,
        "remarks": package.remarks,
        "import_status": package.import_status,
        "imported_at": package.imported_at.isoformat() if package.imported_at else None,
        "dxf_status": package.dxf_status,
        "dxf_at": package.dxf_at.isoformat() if package.dxf_at else None,
        "dxf_user_id": package.dxf_user_id,
        "inspection_status": package.inspection_status,
        "inspected_at": package.inspected_at.isoformat() if package.inspected_at else None,
        "upload_status": package.upload_status,
        "uploaded_at": package.uploaded_at.isoformat() if package.uploaded_at else None,
        "can_edit_general": can_edit_general,
        "files_completed": files,
        "my_roles": my_roles,
        "can_daily_activity": package.production_user_id == viewer.id and package.current_stage in {"not_started", "production", "production_rework"},
        "can_complete_production": package.production_user_id == viewer.id and package.current_stage in {"not_started", "production", "production_rework"},
        "can_qc": package.qc_user_id == viewer.id and package.current_stage == "qc" and package.qc_state == "pending",
        "can_qa": package.qa_user_id == viewer.id and package.current_stage == "qa" and package.qa_state == "pending",
        "can_deliver": (viewer_is_pm or package.team_leader_user_id == viewer.id) and package.current_stage == "delivery_ready",
        "daily_updates": [
            {
                "id": row.id,
                "update_date": row.update_date.isoformat(),
                "work_type": row.work_type,
                "quantity_completed": float(row.achieved_area) if row.achieved_area is not None else 0.0,
                "progress_percent": float(row.progress_percent) if row.progress_percent is not None else None,
                "files_completed": int(row.files_completed or 0),
                "hours_spent": float(row.hours_spent) if row.hours_spent is not None else None,
                "status": row.status,
                "blockers": row.blockers,
                "remarks": row.remarks,
                "updated_by_id": row.updated_by_id,
                "created_at": row.created_at.isoformat(),
            }
            for row in updates
        ],
        "review_history": [
            {
                "review_type": row.review_type,
                "attempt_no": row.attempt_no,
                "decision": row.decision,
                "comments": row.comments,
                "created_at": row.created_at.isoformat(),
            }
            for row in package.reviews
        ],
    }
    if has_items:
        counts = item_ctx.get("aggregate", {})
        payload.update({
            "has_items": True,
            "files_expected": int(item_ctx.get("active_count", 0)),
            "files_production_done": counts.get("files_production_done", 0),
            "files_qc_passed": counts.get("files_qc_passed", 0),
            "files_qa_passed": counts.get("files_qa_passed", 0),
            "files_delivered": counts.get("files_delivered", 0),
            # V8.4 distinct physical-file counters (never inflated by rework attempts).
            "files_assigned": counts.get("files_assigned", 0),
            "files_available": counts.get("files_available", 0),
            "files_production_in_progress": counts.get("production_in_progress", 0),
            "files_production_rework": counts.get("production_rework", 0),
            "files_qc_in_progress": counts.get("qc_in_progress", 0),
            "files_qc_rework": counts.get("qc_rework", 0),
            "files_qa_in_progress": counts.get("qa_in_progress", 0),
            "files_qa_rework": counts.get("qa_rework", 0),
            "files_ready": counts.get("ready", 0),
            "declared_total_files": item_ctx.get("declared_total_files"),
            "stage_bucket": item_ctx.get("stage_bucket"),
            # File-tracked area: derive the DISPLAYED stage + delivery lifecycle from the
            # authoritative physical-file state (never the stale legacy columns).
            "display_stage": item_ctx.get("stage_bucket") or package.current_stage,
            "ready_eligible": bool(_item_expected) and int(counts.get("files_qa_passed", 0)) >= _item_expected,
            "ready_for_delivery": bool(item_ctx.get("ready_confirmed")),
            "delivered": bool(_item_expected) and int(counts.get("files_delivered", 0)) >= _item_expected,
            "item_assignees": {
                **item_ctx.get("item_assignees", {}),
                "team_leader": [item_ctx["team_leader"]] if item_ctx.get("team_leader") else [],
            },
            # Employees receive ONLY their assigned files; PM/TL receive all files.
            "items": item_rows_for_viewer(
                item_ctx["rows"], viewer_id=viewer.id, privileged=(viewer_is_pm or viewer_is_tl),
            ),
        })
        # Delivery is the EXPLICIT step after Ready has been confirmed (never merged with
        # Mark Ready, never automatic) — derived from the physical-file state.
        payload["can_deliver"] = (
            (viewer_is_pm or package.team_leader_user_id == viewer.id)
            and bool(item_ctx.get("ready_confirmed"))
            and not payload["delivered"]
            and payload["ready_eligible"]
        )
    else:
        payload["has_items"] = False
    if viewer_is_pm or viewer_is_tl:
        user_ids = {uid for uid in [package.team_leader_user_id, package.production_user_id, package.qc_user_id, package.qa_user_id] if uid}
        users = {u.id: u for u in db.scalars(select(User).where(User.id.in_(user_ids))).all()} if user_ids else {}
        payload["assignments"] = {
            "team_leader": _user_min(users.get(package.team_leader_user_id)),
            "production": _user_min(users.get(package.production_user_id)),
            "qc": _user_min(users.get(package.qc_user_id)),
            "qa": _user_min(users.get(package.qa_user_id)),
        }
    return payload


def _user_min(user: User | None) -> dict | None:
    if user is None:
        return None
    return {"id": user.id, "full_name": user.full_name, "email": user.email, "employee_id": user.employee_id}


def ortho_dashboard(db: Session, *, actor: User, role: str) -> dict:
    project_ids: set[int] = set()
    if is_technical_pm_role(role):
        # Being e.g. a LiDAR PM never grants every LiDAR project - only the ones this account
        # is actually assigned to (FinanceProjectMasterProfile.project_manager_id == actor.id).
        project_ids.update(int(v) for v in db.scalars(select(FinanceProjectMasterProfile.project_id).where(
            FinanceProjectMasterProfile.project_manager_id == actor.id,
        )).all())
    if role == EMPLOYEE_ROLE:
        project_ids.update(int(v) for v in db.scalars(select(OrthoProjectMember.project_id).where(
            OrthoProjectMember.user_id == actor.id,
            OrthoProjectMember.member_role.in_(TEAM_ROLES),
            OrthoProjectMember.is_active.is_(True),
        )).all())
        # Department isolation: a normal employee only ever sees projects performed by
        # their own department (Employee Master scope), never cross-department work.
        # Employees without a resolvable department keep membership-based visibility.
        employee_department = user_department_code(db, actor)
        if employee_department is not None:
            department_projects = set(
                db.scalars(
                    select(ProjectWorkflow.project_id).where(
                        ProjectWorkflow.performing_department_code == normalize_department_code(employee_department)
                    )
                ).all()
            )
            project_ids &= department_projects
    if role in {ADMIN_ROLE, MANAGEMENT_ROLE}:
        project_ids.update(int(v) for v in db.scalars(select(ProjectWorkflow.project_id)).all())

    if not project_ids:
        return {"viewer_mode": "participant" if role == EMPLOYEE_ROLE else "project_manager", "projects": [], "employees": []}

    project_ids = set(filter_visible_project_ids(db, project_ids))
    if not project_ids:
        return {"viewer_mode": "participant" if role == EMPLOYEE_ROLE else "project_manager", "projects": [], "employees": []}

    projects = list(db.scalars(_project_query().where(FinanceProject.id.in_(project_ids)).order_by(FinanceProject.updated_at.desc())).unique().all())
    workflows = {row.project_id: row for row in db.scalars(select(ProjectWorkflow).where(ProjectWorkflow.project_id.in_(project_ids))).all()}
    result = []
    for project in projects:
        workflow = workflows.get(project.id)
        if workflow is None or workflow.status in {WORKFLOW_DRAFT, WORKFLOW_PENDING_FINANCE, WORKFLOW_FINANCE_RETURNED}:
            continue
        viewer_is_pm = _is_pm(project, actor.id)
        roles = _member_roles(db, project_id=project.id, user_id=actor.id)
        viewer_is_tl = "team_leader" in roles
        status_key = normalized_workflow_status(workflow.status)
        packages = list(db.scalars(_package_query().where(OrthoWorkPackage.project_id == project.id).order_by(OrthoWorkPackage.id.asc())).unique().all())
        all_packages = packages
        # Item-level context (single source of truth for file-based areas). PM / Team Lead /
        # Management keep FULL project visibility; a normal employee sees a package when the
        # legacy package-level columns OR at least one ACTIVE child item assignment matches.
        item_contexts = item_dashboard_context(db, packages)
        if not (viewer_is_pm or viewer_is_tl or role in {ADMIN_ROLE, MANAGEMENT_ROLE}):
            def _employee_can_see(pkg: OrthoWorkPackage) -> bool:
                if actor.id in {pkg.team_leader_user_id, pkg.production_user_id, pkg.qc_user_id, pkg.qa_user_id}:
                    return True
                ctx = item_contexts.get(pkg.id) or {}
                if not ctx.get("has_items"):
                    return False
                return any(
                    row["is_active"]
                    and actor.id in {row.get("production_user_id"), row.get("qc_user_id"), row.get("qa_user_id")}
                    for row in ctx["rows"]
                )
            packages = [pkg for pkg in packages if _employee_can_see(pkg)]
        package_payloads = [
            _package_payload(
                db, pkg,
                viewer=actor,
                viewer_is_pm=viewer_is_pm or role in {ADMIN_ROLE, MANAGEMENT_ROLE},
                viewer_is_tl=viewer_is_tl,
                item_ctx=item_contexts.get(pkg.id),
            )
            for pkg in packages
        ]
        _annotate_rework_packages(db, project.id, package_payloads, packages, all_packages)

        def _stage_for_counts(payload: dict) -> str:
            # File-based areas report the live item stage; legacy areas keep current_stage.
            return payload.get("stage_bucket") or payload["current_stage"]

        summary = {
            "packages": len(package_payloads),
            "production": sum(1 for p in package_payloads if _stage_for_counts(p) in {"not_started", "production", "production_rework"}),
            "qc": sum(1 for p in package_payloads if _stage_for_counts(p) == "qc"),
            "qa": sum(1 for p in package_payloads if _stage_for_counts(p) == "qa"),
            "delivery_ready": sum(1 for p in package_payloads if _stage_for_counts(p) == "delivery_ready"),
            "delivered": sum(1 for p in package_payloads if _stage_for_counts(p) == "delivered"),
        }
        # V8.1 production tracking (additive): server-side progress for this project's
        # visible packages. Production % can legitimately be 100 while QC/QA/Delivery
        # are still pending — both figures are always exposed separately.
        tracking = aggregate_project_progress(packages, workflow.performing_department_code, item_contexts)
        summary["production_progress_percent"] = tracking["production_progress_percent"]
        summary["workflow_progress_percent"] = tracking["workflow_progress_percent"]
        summary["measurement_groups"] = [
            {k: (float(v) if hasattr(v, "as_tuple") else v) for k, v in group.items()}
            for group in tracking["measurement_groups"]
        ]
        base = {
            "project_id": project.id,
            "project_code": project.project_code,
            "client_code": _client_code(project),
            "workflow_status": workflow.status,
            "my_roles": ["project_manager"] if viewer_is_pm else sorted(roles),
            "summary": summary,
            "packages": package_payloads,
            # Original team selection / allocation / completion only exist in the legacy workflow window; during a
            # rework (or any later lifecycle stage) they would be rejected, so they are not offered.
            "can_manage_team": viewer_is_pm and status_key in TEAM_SELECTION_STATUSES,
            "can_allocate_work": viewer_is_tl and status_key in WORK_ALLOCATION_STATUSES,
            "can_complete_project": viewer_is_pm and status_key in WORK_ALLOCATION_STATUSES and bool(package_payloads) and all(_stage_for_counts(p) == "delivered" for p in package_payloads),
            "rework": None,
        }
        if viewer_is_pm or viewer_is_tl or role in {ADMIN_ROLE, MANAGEMENT_ROLE}:
            base.update({
                "start_date": project.start_date.isoformat() if project.start_date else None,
                "end_date": project.end_date.isoformat() if project.end_date else None,
                "scope_text": workflow.scope_text,
                "quantity": float(workflow.quantity) if workflow.quantity is not None else None,
                "quantity_unit": workflow.quantity_unit,
                "priority": workflow.priority,
                "members": _member_map(db, project.id),
                "rework": _rework_context(db, project=project, actor=actor, status_key=status_key, viewer_is_pm=viewer_is_pm, all_packages=all_packages),
            })
        result.append(base)
    return {
        "viewer_mode": "read_only" if role in {ADMIN_ROLE, MANAGEMENT_ROLE} else ("project_manager" if is_technical_pm_role(role) else "participant"),
        "projects": result,
        "employees": (
            employee_options(db, department_code=department_for_pm_role(role))
            if is_technical_pm_role(role) and any(p["can_manage_team"] or (p["rework"] or {}).get("can_confirm_team") for p in result)
            else []
        ),
    }
